			function validateForm() {
			var untrimmedstudLRN = document.forms["enrollmentForm"]["studLRN"].value;
			var untrimmedstudLname = document.forms["enrollmentForm"]["studLname"].value;
			var untrimmedstudFname = document.forms["enrollmentForm"]["studFname"].value;
			var untrimmedstudMname = document.forms["enrollmentForm"]["studMname"].value;
			var untrimmedstudExtname = document.forms["enrollmentForm"]["studExtname"].value;

			var untrimmedstudAge = document.forms["enrollmentForm"]["studAge"].value;

			var untrimmedstudSex = document.forms["enrollmentForm"]["studSex"].value;
			var untrimmedstudBloodType = document.forms["enrollmentForm"]["studBloodType"].value;

			var untrimmedstudIP = document.forms["enrollmentForm"]["studIP"].value;
			var untrimmedstudspecificIP = document.forms["enrollmentForm"]["studspecificIP"].value;
			if (untrimmedstudIP == "1") {
				var untrimmedstudIP = untrimmedstudspecificIP.trim();
			}
			else{
				var untrimmedstudIP = "None";
			}

			var untrimmedstudOtherReligion = document.forms["enrollmentForm"]["studOtherReligion"].value;
			var untrimmedstudReligion = document.forms["enrollmentForm"]["studReligion"].value;
			if (untrimmedstudReligion == "others") {
				var untrimmedstudReligion = untrimmedstudOtherReligion.trim();
			}
			var untrimmedstudBdate = document.forms["enrollmentForm"]["studBirthDate"].value;
			
			var untrimmedstudStatus = document.forms["enrollmentForm"]["studStatus"].value;

			var untrimmedstudHouseNoandStreet = document.forms["enrollmentForm"]["studHouseNoandStreet"].value;
			var untrimmedstudSubdBrgy = document.forms["enrollmentForm"]["studSubdBrgy"].value;			
			var untrimmedstudCityMun = document.forms["enrollmentForm"]["studCityMun"].value;
			var untrimmedstudProvince = document.forms["enrollmentForm"]["studProvince"].value;
			var untrimmedstudCountry = document.forms["enrollmentForm"]["studCountry"].value;
			var untrimmedstudPostal = document.forms["enrollmentForm"]["studPostal"].value;

			var untrimmedstudMothersName = document.forms["enrollmentForm"]["studMothersName"].value;
			var untrimmedstudFathersName = document.forms["enrollmentForm"]["studFathersName"].value;
			var untrimmedstudGuardiansName = document.forms["enrollmentForm"]["studGuardiansName"].value;


			var untrimmedstudTelephone = document.forms["enrollmentForm"]["studTelephone"].value;
			var untrimmedstudCellphone = document.forms["enrollmentForm"]["studCellphone"].value;
			var untrimmedstudTelephone = document.forms["enrollmentForm"]["studTelephone"].value;
			var untrimmedstudEmail = document.forms["enrollmentForm"]["studEmail"].value;

			var untrimmedjrhighName = document.forms["enrollmentForm"]["jrhighName"].value;
			var untrimmedjrhighAddress = document.forms["enrollmentForm"]["jrhighAddress"].value;
			var untrimmedjrhighCompletion = document.forms["enrollmentForm"]["jrhighCompletion"].value;

			var untrimmedstudSpecialization = document.forms["enrollmentForm"]["studSpecialization"].value;
			var untrimmedstudGradeLevel = document.forms["enrollmentForm"]["studGradeLevel"].value;

			var untrimmedstudSection = document.forms["enrollmentForm"]["studSection"].value;

			var untrimmedstudSem = document.forms["enrollmentForm"]["studSem"].value;

			var untrimmedstudVoucher = document.forms["enrollmentForm"]["studVoucher"].value;

			var studLRN = untrimmedstudLRN.trim();
			var studLname = untrimmedstudLname.trim();
			var studFname = untrimmedstudFname.trim();
			var studMname = untrimmedstudMname.trim();
			var studExtname = untrimmedstudExtname.trim();

			var studAge = untrimmedstudAge.trim();

			var studSex = untrimmedstudSex.trim();
			var studBloodType = untrimmedstudBloodType.trim();

			var studIP = untrimmedstudIP.trim();
			var studReligion = untrimmedstudReligion.trim();


			var studBdate = untrimmedstudBdate.trim();

			var studStatus = untrimmedstudStatus.trim();

			var studHouseNoandStreet = untrimmedstudHouseNoandStreet.trim();
			var studSubdBrgy = untrimmedstudSubdBrgy.trim();			
			var studCityMun = untrimmedstudCityMun.trim();
			var studProvince = untrimmedstudProvince.trim();
			var studCountry = untrimmedstudCountry.trim();
			var studPostal = untrimmedstudPostal.trim();

			var studMothersName = untrimmedstudMothersName.trim();
			var studFathersName = untrimmedstudFathersName.trim();
			var studGuardiansName = untrimmedstudGuardiansName.trim();


			var studCellphone = untrimmedstudCellphone.trim();
			var studTelephone = untrimmedstudTelephone.trim();
			var studEmail = untrimmedstudEmail.trim();

			var jrhighName = untrimmedjrhighName.trim();
			var jrhighAddress = untrimmedjrhighAddress.trim();
			var jrhighCompletion = untrimmedjrhighCompletion.trim();

			var studSpecialization = untrimmedstudSpecialization.trim();
			var studGradeLevel = untrimmedstudGradeLevel.trim();
			var studSection = untrimmedstudSection.trim();			
			var studSem = untrimmedstudSem.trim();

			var studVoucher = untrimmedstudVoucher.trim();

			document.getElementById('studLnameError').innerHTML = validate(studLname);
			document.getElementById('studFnameError').innerHTML = validate(studFname);
			document.getElementById('studMnameError').innerHTML = validate(studMname);

			document.getElementById('studReligionError').innerHTML = validate(studReligion);
			document.getElementById('studIPError').innerHTML = validate(studIP);

			document.getElementById('studHouseNoandStreetError').innerHTML = validatewithnum(studHouseNoandStreet);
			document.getElementById('studSubdBrgyError').innerHTML = validatewithnum(studSubdBrgy);			
			document.getElementById('studCityMunError').innerHTML = validate(studCityMun);
			document.getElementById('studProvinceError').innerHTML = validate(studProvince);
			document.getElementById('studCountryError').innerHTML = validate(studCountry);

			document.getElementById('studMothersNameError').innerHTML = validateparents(studMothersName);
			document.getElementById('studFathersNameError').innerHTML = validateparents(studFathersName);
			document.getElementById('studGuardiansNameError').innerHTML = validateparents(studGuardiansName);

			document.getElementById('studCellphoneError').innerHTML = validatecellnumbers(studCellphone);
			document.getElementById('studEmailError').innerHTML = validateEmail(studEmail);
			document.getElementById('jrhighNameError').innerHTML = validatewithnum(jrhighName);
			document.getElementById('jrhighAddressError').innerHTML = validatewithnum(jrhighAddress);

if (validate(studLname) == "" && validate(studFname) == "" && validate(studMname) == "" && validate(studReligion) == "" && validate(studIP) == ""  && validatewithnum(studHouseNoandStreet) == "" && validatewithnum(studSubdBrgy) == "" && validate(studCityMun) == "" && validate(studProvince) == "" && validate(studCountry) == "" && validateparents(studMothersName) == "" && validateparents(studFathersName) == "" && validateparents(studGuardiansName) == "" && validatecellnumbers(studCellphone) == "" && validateEmail(studEmail) == "" && validatewithnum(jrhighName) == "" && validatewithnum(jrhighAddress)=="") {

				var today = new Date();
				var studEnrollDate =  today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
				var studSY1 = today.getFullYear();
				var studSY2 = studSY1+1;
				var studSY = studSY1+"-"+studSY2;


				var xmlhttp = new XMLHttpRequest();
      		  	xmlhttp.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
            			var registrationfeedback = this.responseText;

            			if (registrationfeedback == "Student already registered!") {
            			alert("Student already registered!");
            			document.location.reload();

            			}
            			else{
            			alert("Sucessful student registration!");
        				var urltoCut = registrationfeedback;
            			var urlarray = urltoCut.split("?", 2);
            			window.open("statementofaccount.php?"+urlarray[1]);
            			newPopup(registrationfeedback);
            			document.location.reload();

            			}
            			

           			}
    	   		};
 				xmlhttp.open("GET", "enrollmentformsubmit.php?studLname=" + studLname + 
 					"&studFname=" + studFname+
 					"&studMname=" + studMname+
 					"&studExtname=" + studExtname+
 					"&studLRN=" +studLRN+
 					"&studAge="+studAge+
 					"&studSex="+studSex+
 					"&studBloodType="+studBloodType+
 					"&studIP="+studIP+
 					"&studReligion="+studReligion+
 					"&studBdate="+studBdate+
 					"&studStatus="+studStatus+
 					"&studHouseNoandStreet="+studHouseNoandStreet+
 					"&studSubdBrgy="+studSubdBrgy+
 					"&studCityMun="+studCityMun+
 					"&studProvince="+studProvince+
 					"&studCountry="+studCountry+
 					"&studPostal="+studPostal+
 					"&studMothersName="+studMothersName+
 					"&studFathersName="+studFathersName+
 					"&studGuardiansName="+studGuardiansName+
 					"&studCellphone="+studCellphone+
 					"&studTelephone="+studTelephone+
 					"&studEmail="+studEmail+
 					"&jrhighName="+jrhighName+
 					"&jrhighAddress="+jrhighAddress+
 					"&jrhighCompletion="+jrhighCompletion+
 					"&studSpecialization="+studSpecialization+
 					"&studGradeLevel="+studGradeLevel+
 					"&studSection="+studSection+
 					"&studSem="+studSem+
 					"&studEnrollDate="+studEnrollDate+
 					"&studSY="+studSY+
 					"&studVoucher="+studVoucher, true);
       			xmlhttp.send();


}

			return false;
}
function showIPfield(ipvalue){
			var element=document.getElementById('studspecificIP');
			 if(ipvalue=='1'){
			 			   element.style.display='block';
			 			}
			 else {  
			 			   element.style.display='none';
			 			}

}
function validateUpdateForm() {

			var untrimmedstudid = document.forms["updateStudForm"]["studid"].value;
			var untrimmedstudLRN = document.forms["updateStudForm"]["studLRN"].value;
			var untrimmedstudLname = document.forms["updateStudForm"]["studLname"].value;
			var untrimmedstudFname = document.forms["updateStudForm"]["studFname"].value;
			var untrimmedstudMname = document.forms["updateStudForm"]["studMname"].value;
			var untrimmedstudExtname = document.forms["updateStudForm"]["studExtname"].value;

			var untrimmedstudAge = document.forms["updateStudForm"]["studAge"].value;

			var untrimmedstudSex = document.forms["updateStudForm"]["studSex"].value;
			var untrimmedstudBloodType = document.forms["updateStudForm"]["studBloodType"].value;

			var untrimmedstudIP = document.forms["updateStudForm"]["studIP"].value;
			var untrimmedstudOtherReligion = document.forms["updateStudForm"]["studOtherReligion"].value;
			var untrimmedstudReligion = document.forms["updateStudForm"]["studReligion"].value;
			if (untrimmedstudReligion == "others") {
				var untrimmedstudReligion = untrimmedstudOtherReligion.trim();
			}

			var untrimmedstudStatus = document.forms["updateStudForm"]["studStatus"].value;

			var untrimmedstudHouseNoandStreet = document.forms["updateStudForm"]["studHouseNoandStreet"].value;
			var untrimmedstudSubdBrgy = document.forms["updateStudForm"]["studSubdBrgy"].value;			
			var untrimmedstudCityMun = document.forms["updateStudForm"]["studCityMun"].value;
			var untrimmedstudProvince = document.forms["updateStudForm"]["studProvince"].value;
			var untrimmedstudCountry = document.forms["updateStudForm"]["studCountry"].value;
			var untrimmedstudPostal = document.forms["updateStudForm"]["studPostal"].value;

			var untrimmedstudMothersName = document.forms["updateStudForm"]["studMothersName"].value;
			var untrimmedstudFathersName = document.forms["updateStudForm"]["studFathersName"].value;
			var untrimmedstudGuardiansName = document.forms["updateStudForm"]["studGuardiansName"].value;


			var untrimmedstudTelephone = document.forms["updateStudForm"]["studTelephone"].value;
			var untrimmedstudCellphone = document.forms["updateStudForm"]["studCellphone"].value;
			var untrimmedstudTelephone = document.forms["updateStudForm"]["studTelephone"].value;
			var untrimmedstudEmail = document.forms["updateStudForm"]["studEmail"].value;

			var studid = untrimmedstudid.trim();
			var studLRN = untrimmedstudLRN.trim();
			var studLname = untrimmedstudLname.trim();
			var studFname = untrimmedstudFname.trim();
			var studMname = untrimmedstudMname.trim();
			var studExtname = untrimmedstudExtname.trim();

			var studAge = untrimmedstudAge.trim();

			var studSex = untrimmedstudSex.trim();
			var studBloodType = untrimmedstudBloodType.trim();

			var studIP = untrimmedstudIP.trim();

			var studReligion = untrimmedstudReligion.trim();



			var studStatus = untrimmedstudStatus.trim();

			var studHouseNoandStreet = untrimmedstudHouseNoandStreet.trim();
			var studSubdBrgy = untrimmedstudSubdBrgy.trim();			
			var studCityMun = untrimmedstudCityMun.trim();
			var studProvince = untrimmedstudProvince.trim();
			var studCountry = untrimmedstudCountry.trim();
			var studPostal = untrimmedstudPostal.trim();

			var studMothersName = untrimmedstudMothersName.trim();
			var studFathersName = untrimmedstudFathersName.trim();
			var studGuardiansName = untrimmedstudGuardiansName.trim();


			var studCellphone = untrimmedstudCellphone.trim();
			var studTelephone = untrimmedstudTelephone.trim();
			var studEmail = untrimmedstudEmail.trim();


			document.getElementById('LnameError').innerHTML = validate(studLname);
			document.getElementById('FnameError').innerHTML = validate(studFname);
			document.getElementById('MnameError').innerHTML = validate(studMname);

			document.getElementById('ReligionError').innerHTML = validate(studReligion);



			document.getElementById('HouseNoandStreetError').innerHTML = validatewithnum(studHouseNoandStreet);
			document.getElementById('SubdBrgyError').innerHTML = validatewithnum(studSubdBrgy);			
			document.getElementById('CityMunError').innerHTML = validate(studCityMun);
			document.getElementById('ProvinceError').innerHTML = validate(studProvince);
			document.getElementById('CountryError').innerHTML = validate(studCountry);

			document.getElementById('MothersNameError').innerHTML = validateparents(studMothersName);
			document.getElementById('FathersNameError').innerHTML = validateparents(studFathersName);
			document.getElementById('GuardiansNameError').innerHTML = validateparents(studGuardiansName);

			document.getElementById('CellphoneError').innerHTML = validatecellnumbers(studCellphone);
			document.getElementById('EmailError').innerHTML = validateEmail(studEmail);

if (validate(studLname) == "" && validate(studFname) == "" && validate(studMname) == "" && validate(studReligion) == "" && validatewithnum(studHouseNoandStreet) == "" && validatewithnum(studSubdBrgy) == "" && validate(studCityMun) == "" && validate(studProvince) == "" && validate(studCountry) == "" && validateparents(studMothersName) == "" && validateparents(studFathersName) == "" && validateparents(studGuardiansName) == "" && validatecellnumbers(studCellphone) == "" && validateEmail(studEmail== "") ) {



				var xmlhttp4 = new XMLHttpRequest();
      		  	xmlhttp4.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {

            			alert(this.responseText);        	
            			document.location.reload();
           			}
    	   		};
 				xmlhttp4.open("GET", "updateformsubmit.php?studLname=" + studLname + 
 					"&studFname=" + studFname+
 					"&studMname=" + studMname+
 					"&studExtname=" + studExtname+
 					"&studLRN=" +studLRN+
 					"&studAge="+studAge+
 					"&studSex="+studSex+
 					"&studBloodType="+studBloodType+
 					"&studIP="+studIP+
 					"&studReligion="+studReligion+
 					"&studStatus="+studStatus+
 					"&studHouseNoandStreet="+studHouseNoandStreet+
 					"&studSubdBrgy="+studSubdBrgy+
 					"&studCityMun="+studCityMun+
 					"&studProvince="+studProvince+
 					"&studCountry="+studCountry+
 					"&studPostal="+studPostal+
 					"&studMothersName="+studMothersName+
 					"&studFathersName="+studFathersName+
 					"&studGuardiansName="+studGuardiansName+
 					"&studCellphone="+studCellphone+
 					"&studTelephone="+studTelephone+
 					"&studEmail="+studEmail+
 					"&studid="+studid , true);
       			xmlhttp4.send();


}
else{
	alert("Form fill-up failure! ");
}

			return false;
}

		function otherreligions(val){
			var element=document.getElementById('studOtherReligion');
			 if(val=='others')
			   element.style.display='block';
			 else  
			   element.style.display='none';
		}
		function otherreligionsupdate(val){
			var element=document.getElementById('studOtherReligion');
			 if(val=='others')
			   element.style.display='block';
			 else  
			   element.style.display='none';
		}
		function validate(formval){

			if (formval == "") {
				//alert(formval+ "."+errornumber);
				return "Please populate this field";
			}
			else if ( /[^a-zA-Z\ -.,]/.test(formval)) {
				return "Please enter a valid answer in all fields";
			}
			else{
				return "";
			}

		}
		function validatewithnum(formval){

			if (formval == "") {
				return "Please populate this field";
			}
			else if ( /[^a-zA-Z0-9\ -.,]/.test(formval)) {
				return "Please enter a valid answer in all fields";
			}
			else{
				return "";
			}

		}
		function validateparents(formval){
			if (formval == "") {
				return "Please enter your name";
			}
			else if ( /[^a-zA-Z\ -.]/.test(formval)) {
				return "Please enter a valid name";
			}
			else if (!/[/ /]/.test(formval)) {
				return "A name must have at least two words";
			}
			else if (formval.length > 90) {
				return "Name must only contain 90 characters";
			}
			else{
				return "";
			}

		}
		function validatecellnumbers(formval){
			if (/[^0-9]/.test(formval)) {
				return "Please enter a valid number";
			}
			else if (!formval.startsWith("09")) {
				return "A valid number starts with '09'";
			}
			else{
				return "";
			}
		}
		function validateEmail(formval){
			if (formval == "") {
				return "Please enter your email";
			}
			else if (!/[@/]/.test(formval) || !/[./]/.test(formval) )  {
				return "Invalid Email";
			}
			else if (/[/ /]/.test(formval)) {
				return "Email address must not contain whitespaces";
			}
			else if (formval.length > 30) {
				return "Email must only have 30 characters";
			}
			else{
				return "";
			}
		}
		function getSections(){
			var gradelevel = document.getElementById("studGradeLevel").value;
			var specializationID = document.getElementById("studSpecialization").value;

				var xmlhttp2 = new XMLHttpRequest();
      		  	xmlhttp2.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
               document.getElementById("studSection").innerHTML =this.responseText;
                return true;

           			}
    	   		};
 				xmlhttp2.open("GET", "getsections.php?gradelevel=" + gradelevel+"&specializationID="+ specializationID, true);
       			xmlhttp2.send();

		}

function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=900,width=900,left=225,top=10,resizable=no,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
function sendquery(studentToSearch,schoolYear, semester, criteria){
	if (studentToSearch !== null && studentToSearch !== "" && criteria !== null && criteria !== "" && schoolYear !== null && schoolYear !== "" && semester !== null && semester !== "") {
		var xmlhttp3 = new XMLHttpRequest();
      		  	xmlhttp3.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
      			document.getElementById("forallresults").style.display = "none";
				document.getElementById("forallresultstable").style.display = "none";
		document.getElementById("resultsTable").style.display = "table";
               document.getElementById("resultsTable").innerHTML =this.responseText;
                return true;
           			}
    	   		};
 				xmlhttp3.open("GET", "getstudents.php?studentToSearch=" + studentToSearch+"&schoolYear="+ schoolYear+"&semester="+ semester+"&criteria="+criteria, true);
       			xmlhttp3.send();
	}
	else{
		document.getElementById("forallresults").style.display = "table";
		document.getElementById("forallresultstable").style.display = "table";
		document.getElementById("resultsTable").style.display = "none";
	}
			
}

function displayForm(){
	var tochange= document.getElementById("updateStudForm");
	var toHide= document.getElementById("toHide");
	if(tochange.style.display ="none"){
		tochange.style.display="block";
		toHide.style.display="none";

	}

	else{
		toHide.style.display="block";
		tochange.style.display="none";
	}

}
function hideupdateform(){
	var tochange= document.getElementById("toHide");
	var toHide= document.getElementById("updateStudForm");
	if(tochange.style.display ="none"){
		tochange.style.display="block";
		toHide.style.display="none";

	}

	else{
		toHide.style.display="block";
		tochange.style.display="none";
	}

}
function openspecializationsreport(){
	var semrep = document.forms['enrollmentReport']['semester'].value;
	var syrep =  document.forms['enrollmentReport']['schoolYear'].value;
	getspecializationreps(semrep, syrep);

	document.getElementById("specializations").style.display = "block";
	document.getElementById("locations").style.display = "none";
	document.getElementById("jrhigh").style.display = "none";
	document.getElementById("gradelevels").style.display = "none";


}

function openlocationsreport(){
	var semrep = document.forms['enrollmentReport']['semester'].value;
	var syrep =  document.forms['enrollmentReport']['schoolYear'].value;
	getlocationreps(semrep, syrep);


	document.getElementById("locations").style.display = "block";
	document.getElementById("specializations").style.display = "none";
	document.getElementById("jrhigh").style.display = "none";
	document.getElementById("gradelevels").style.display = "none";
}
function openjrhighreport(){
	var semrep = document.forms['enrollmentReport']['semester'].value;
	var syrep =  document.forms['enrollmentReport']['schoolYear'].value;
	getjrhighreps(semrep, syrep);

	document.getElementById("jrhigh").style.display = "block";
	document.getElementById("locations").style.display = "none";
	document.getElementById("specializations").style.display = "none";
	document.getElementById("gradelevels").style.display = "none";

}
function opengradelevelsreport(){
	var semrep = document.forms['enrollmentReport']['semester'].value;
	var syrep =  document.forms['enrollmentReport']['schoolYear'].value;
	getgradelevelreps(semrep, syrep);


	document.getElementById("gradelevels").style.display = "block";
	document.getElementById("locations").style.display = "none";
	document.getElementById("jrhigh").style.display = "none";
	document.getElementById("specializations").style.display = "none";
}
function allreports(){
	document.getElementById("specializations").style.display = "block";
	document.getElementById("locations").style.display = "block";
	document.getElementById("jrhigh").style.display = "block";
	document.getElementById("gradelevels").style.display = "block";

}

function enrollmentreportquery(semester, schoolyear){
	getspecializationreps(semester, schoolyear);
	getlocationreps(semester, schoolyear);
	getjrhighreps(semester, schoolyear);
	getgradelevelreps(semester, schoolyear);

}
function gettabledata(tablename){
	var mytable = document.getElementById(tablename);
	var rowlength = mytable.rows.length;
	var tbllabels = [];
	var tbldata = [];

	for (var i = 0; i < rowlength; i++) {
		var tablecells = mytable.rows.item(i).cells;
		var celllength = tablecells.length;
		for (var j = 0; j < celllength; j++) {
			if (j==0) {
				tbllabels.push(tablecells.item(j).innerHTML);
			}
			else{
				tbldata.push(tablecells.item(j).innerHTML);
			}
		}

	}
		bars(tbldata, tbllabels, tablename);
		pies(tbldata, tbllabels, tablename);
		lines(tbldata, tbllabels, tablename);
}

function getspecializationreps(semrep, syrep){
	//document.getElementById("specializationstable").innerHTML = "<tr><td>lol</td></tr>";
				xmlhttp4 = new XMLHttpRequest();
      		  	xmlhttp4.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
              document.getElementById("specializationstable").innerHTML =this.responseText;
              gettabledata("specializationstable");
                return true;
           			}
    	   		};
 				xmlhttp4.open("GET", "getspecializationreports.php?semrep=" + semrep+"&syrep="+ syrep, true);
       			xmlhttp4.send();
}
function getlocationreps(semrep, syrep){
				xmlhttp5 = new XMLHttpRequest();
      		  	xmlhttp5.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
              document.getElementById("locationstable").innerHTML =this.responseText;
              gettabledata("locationstable");
                return true;
           			}
    	   		};
 				xmlhttp5.open("GET", "getlocationreps.php?semrep=" + semrep+"&syrep="+ syrep, true);
       			xmlhttp5.send();
}function getjrhighreps(semrep, syrep){
				xmlhttp5 = new XMLHttpRequest();
      		  	xmlhttp5.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
              document.getElementById("jrhightable").innerHTML =this.responseText;
              gettabledata("jrhightable");
                return true;
           			}
    	   		};
 				xmlhttp5.open("GET", "getjrhighreps.php?semrep=" + semrep+"&syrep="+ syrep, true);
       			xmlhttp5.send();
}function getgradelevelreps(semrep, syrep){
				xmlhttp6 = new XMLHttpRequest();
      		  	xmlhttp6.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
              document.getElementById("gradelevelstable").innerHTML =this.responseText;
              gettabledata("gradelevelstable");
                return true;
           			}
    	   		};
 				xmlhttp6.open("GET", "getgradelevelreps.php?semrep=" + semrep+"&syrep="+ syrep, true);
       			xmlhttp6.send();
}
function validateLogin(){

	var usernameRaw = document.forms["crniLogInForm"]["registrarUsername"].value;
	var passwordRaw = document.forms["crniLogInForm"]["registrarPassword"].value;

	var username = usernameRaw.trim();
	var password = passwordRaw.trim();

	document.getElementById("usernameError").innerHTML =  validatewithnum(username);
	document.getElementById("passwordError").innerHTML =  validatewithnum(password);

	if (validatewithnum(username) == "" && validatewithnum(password) == "") {
		xmlhttp6 = new XMLHttpRequest();
      		  	xmlhttp6.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
            			var loginFeedback = this.responseText;
            			alert(loginFeedback);
            			if (loginFeedback != "Incorrect username or password!") {
            				alert(username);
            				if(username=="admin"){
            					window.location.href ="admin.php";
            				}else{
            					window.location.href ="index.php";
            				}
            			}
            			else{
            				document.location.reload();
            			}


                return true;
           			}
    	   		};
 				xmlhttp6.open("GET", "validatelogin.php?crni_reg_username=" + username+"&crni_reg_password="+ password, true);
       			xmlhttp6.send();
	}

	return false;
}
function registrarlogout(){
	xmlhttp7 = new XMLHttpRequest();
      		  	xmlhttp7.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {
            				document.location.reload();
           			}
    	   		};
 				xmlhttp7.open("GET", "logout.php", true);
       			xmlhttp7.send();
}