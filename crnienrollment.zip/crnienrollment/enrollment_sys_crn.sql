-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2019 at 10:48 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrollment_sys_crn`
--

-- --------------------------------------------------------

--
-- Table structure for table `campus_info`
--

CREATE TABLE `campus_info` (
  `campus_code` varchar(3) NOT NULL,
  `campus_name` varchar(50) NOT NULL,
  `campus_location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campus_info`
--

INSERT INTO `campus_info` (`campus_code`, `campus_name`, `campus_location`) VALUES
('ANN', 'Computer Research Network, Inc. Annex', 'Purok 8, Poblacion, Trento, Agusan del Sur (Near West Central Elementary School)'),
('EXT', 'Computer Research Network, Inc. Extension', 'Purok 2, Poblacion, Trento, Agusan del Sur (Near Seventh Day Adventist Church)'),
('MAI', 'Computer Research Network, Inc. Main Campus', 'Purok 7, Poblacion, Trento, Agusan del Sur (Near Public Market)');

-- --------------------------------------------------------

--
-- Table structure for table `classroom_info`
--

CREATE TABLE `classroom_info` (
  `classroom_no` varchar(20) NOT NULL,
  `classroom` varchar(15) NOT NULL,
  `campus_code` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classroom_info`
--

INSERT INTO `classroom_info` (`classroom_no`, `classroom`, `campus_code`) VALUES
('ANN-101', '101', 'ANN'),
('ANN-102', '102', 'ANN'),
('ANN-103', '103', 'ANN'),
('ANN-AutomotiveLab', 'AutomotiveLab', 'ANN'),
('EXT-101', '101', 'EXT'),
('EXT-102', '102', 'EXT'),
('EXT-103', '103', 'EXT'),
('EXT-104', '104', 'EXT'),
('EXT-105', '105', 'EXT'),
('EXT-106', '106', 'EXT'),
('EXT-AutomotiveLab', 'AutomotiveLab', 'EXT'),
('MAI-101', '101', 'MAI'),
('MAI-102', '102', 'MAI'),
('MAI-103', '103', 'MAI'),
('MAI-104', '104', 'MAI'),
('MAI-201', '201', 'MAI'),
('MAI-202', '202', 'MAI'),
('MAI-ComLab1', 'ComLab1', 'MAI'),
('MAI-ComLab2', 'ComLab2', 'MAI');

-- --------------------------------------------------------

--
-- Table structure for table `class_assignment`
--

CREATE TABLE `class_assignment` (
  `class_id` int(5) NOT NULL,
  `classroom_no` varchar(20) NOT NULL,
  `semester_offered` int(1) NOT NULL,
  `section_id` int(3) NOT NULL,
  `instructor_id` int(5) NOT NULL,
  `subject_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_assignment`
--

INSERT INTO `class_assignment` (`class_id`, `classroom_no`, `semester_offered`, `section_id`, `instructor_id`, `subject_code`) VALUES
(1, 'MAI-101', 1, 14, 3, 'OCC 11'),
(2, 'MAI-103', 1, 15, 3, 'OCC 11'),
(3, 'MAI-102', 1, 13, 3, 'OCC 11'),
(4, 'EXT-104', 1, 24, 3, 'PRII 12'),
(5, 'EXT-103', 1, 20, 3, 'PRII 12'),
(6, 'EXT-101', 1, 21, 3, 'MIL'),
(7, 'EXT-103', 1, 20, 3, 'MIL'),
(8, 'ANN-103', 1, 18, 4, 'OCC 11'),
(9, 'ANN-101', 1, 17, 4, 'OCC 11'),
(10, 'MAI-104', 1, 22, 4, 'IPHP'),
(11, 'MAI-102', 1, 13, 4, 'EAPP'),
(12, 'MAI-101', 1, 14, 4, 'EAPP'),
(13, 'ANN-102', 1, 16, 4, 'OCC 11'),
(14, 'MAI-104', 1, 22, 5, 'PRII 12'),
(15, 'MAI-104', 1, 22, 5, 'CPAR'),
(16, 'MAI-103', 1, 15, 5, 'EAPP'),
(17, 'ANN-102', 1, 16, 5, 'EAPP'),
(18, 'ANN-101', 1, 17, 5, 'EAPP'),
(19, 'ANN-103', 1, 18, 5, 'FPL'),
(20, 'ANN-103', 1, 18, 5, 'EAPP'),
(21, 'ANN-101', 1, 17, 6, 'KPWKP'),
(22, 'ANN-103', 1, 18, 6, 'KPWKP'),
(23, 'MAI-103', 1, 15, 6, 'KPWKP'),
(24, 'MAI-102', 1, 13, 6, 'KPWKP'),
(25, 'MAI-103', 1, 15, 6, 'FPL'),
(26, 'MAI-101', 1, 14, 6, 'KPWKP'),
(27, 'ANN-102', 1, 16, 6, 'KPWKP'),
(28, 'MAI-102', 1, 13, 6, 'FPL'),
(29, 'EXT-103', 1, 20, 7, 'ELS'),
(30, 'EXT-101', 1, 21, 7, 'ELS'),
(31, 'EXT-104', 1, 24, 7, 'ELS'),
(32, 'EXT-102', 1, 23, 7, 'ELS'),
(33, 'ANN-102', 1, 16, 7, 'FPL'),
(34, 'ANN-101', 1, 17, 7, 'FPL'),
(35, 'MAI-101', 1, 14, 7, 'FPL'),
(36, 'MAI-104', 1, 22, 8, 'ELS'),
(37, 'ANN-103', 1, 18, 8, 'PD'),
(38, 'ANN-102', 1, 16, 8, 'PD'),
(39, 'MAI-103', 1, 15, 8, 'PD'),
(40, 'ANN-101', 1, 17, 8, 'PD'),
(41, 'MAI-102', 1, 15, 9, 'GM'),
(42, 'MAI-104', 1, 14, 9, 'GM'),
(43, 'MAI-101', 1, 16, 9, 'GM'),
(44, 'MAI-101', 1, 18, 9, 'GM'),
(45, 'EXT-102', 1, 17, 9, 'GM'),
(46, 'EXT-103', 1, 13, 9, 'GM'),
(47, 'EXT-101', 1, 21, 10, 'IPM'),
(48, 'EXT-103', 1, 20, 10, 'IPM'),
(49, 'EXT-102', 1, 23, 10, 'IPM'),
(50, 'EXT-104', 1, 24, 10, 'IPM'),
(51, 'EXT-103', 1, 20, 10, 'CPAR'),
(52, 'EXT-102', 1, 23, 10, 'CPAR'),
(53, 'EXT-104', 1, 24, 10, 'CPAR'),
(54, 'EXT-101', 1, 21, 10, 'CPAR');

-- --------------------------------------------------------

--
-- Table structure for table `class_list`
--

CREATE TABLE `class_list` (
  `student_id` int(6) NOT NULL,
  `class_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_list`
--

INSERT INTO `class_list` (`student_id`, `class_id`) VALUES
(1, 3),
(1, 11),
(1, 24),
(1, 28),
(1, 46),
(2, 13),
(2, 17),
(2, 27),
(2, 33),
(2, 38),
(2, 43),
(3, 6),
(3, 30),
(3, 47),
(3, 54);

-- --------------------------------------------------------

--
-- Table structure for table `department_info`
--

CREATE TABLE `department_info` (
  `department_code` int(3) NOT NULL,
  `department_head` varchar(100) NOT NULL,
  `department_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_info`
--

INSERT INTO `department_info` (`department_code`, `department_head`, `department_title`) VALUES
(1, 'ICT', 'Information and Communications Technology'),
(2, 'IA', 'Industrial Arts'),
(3, 'HE', 'Home Economics');

-- --------------------------------------------------------

--
-- Table structure for table `instructor_info`
--

CREATE TABLE `instructor_info` (
  `instructor_id` int(5) NOT NULL,
  `inst_fname` varchar(30) NOT NULL,
  `inst_lname` varchar(30) NOT NULL,
  `inst_mname` varchar(30) NOT NULL,
  `inst_address` varchar(150) NOT NULL,
  `inst_sex` varchar(10) NOT NULL,
  `advisory_section_id` int(3) NOT NULL,
  `inst_email` varchar(30) NOT NULL,
  `inst_mobile` varchar(11) NOT NULL,
  `inst_telephone` varchar(13) NOT NULL,
  `department_code` int(3) NOT NULL,
  `inst_age` int(3) NOT NULL,
  `inst_religion` varchar(30) NOT NULL,
  `inst_birthdate` date NOT NULL,
  `inst_employmentdate` date NOT NULL,
  `inst_bloodtype` varchar(5) NOT NULL,
  `inst_picture` blob NOT NULL,
  `inst_status` varchar(15) NOT NULL,
  `inst_TIN` int(15) NOT NULL,
  `inst_philhealthmdr` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instructor_info`
--

INSERT INTO `instructor_info` (`instructor_id`, `inst_fname`, `inst_lname`, `inst_mname`, `inst_address`, `inst_sex`, `advisory_section_id`, `inst_email`, `inst_mobile`, `inst_telephone`, `department_code`, `inst_age`, `inst_religion`, `inst_birthdate`, `inst_employmentdate`, `inst_bloodtype`, `inst_picture`, `inst_status`, `inst_TIN`, `inst_philhealthmdr`) VALUES
(1, 'Dylone Alfon', 'Felongco', 'G.', 'Purok 8, Poblacion, Trento, Agusan del Sur', 'Male', 0, 'kulitapsq5@gmail.com', '09460975441', '(085)255-2465', 1, 24, 'Christian', '0000-00-00', '0000-00-00', '', '', 'Single', 0, 0),
(3, 'Lance ', 'Magno', 'P.', '', '', 0, '', '', '', 2, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(4, 'Christian', 'Dela Cruz', 'P.', '', '', 0, '', '', '', 3, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(5, 'Ronel', 'Dinaguit', 'P.', '', '', 0, '', '', '', 1, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(6, 'Julious', 'Maco', 'L.', '', '', 0, '', '', '', 2, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(7, 'Jasteen', 'Abella', 'P.', '', '', 0, '', '', '', 3, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(8, 'Caitlen', 'Magno', 'D.', '', '', 0, '', '', '', 1, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(9, 'Ronnie', 'Bescara', 'T.', '', '', 0, '', '', '', 2, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(10, 'Jonnes', 'Dinaguit', 'D.', '', '', 0, '', '', '', 3, 0, '', '0000-00-00', '0000-00-00', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jr_high_info`
--

CREATE TABLE `jr_high_info` (
  `stud_jrhigh_number` int(5) NOT NULL,
  `jrhigh_name` varchar(100) NOT NULL,
  `jrhigh_address` varchar(100) NOT NULL,
  `jrhigh_completion` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jr_high_info`
--

INSERT INTO `jr_high_info` (`stud_jrhigh_number`, `jrhigh_name`, `jrhigh_address`, `jrhigh_completion`) VALUES
(1, 'Trento National High School', 'Trento, Agusan del Sur, Philippines', '2019-03'),
(2, 'Laak National High School', 'Laak, Compostela Valley, Philippines', '2010-04'),
(3, 'Laak National High School', 'Laak, Compostela Valley, Philippines', '2011-04');

-- --------------------------------------------------------

--
-- Table structure for table `registrar_info`
--

CREATE TABLE `registrar_info` (
  `registrar_id` int(3) NOT NULL,
  `registrar_username` varchar(20) NOT NULL,
  `registrar_pass` varchar(100) NOT NULL,
  `registrar_fname` varchar(50) NOT NULL,
  `registrar_lname` varchar(50) NOT NULL,
  `registrar_mname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrar_info`
--

INSERT INTO `registrar_info` (`registrar_id`, `registrar_username`, `registrar_pass`, `registrar_fname`, `registrar_lname`, `registrar_mname`) VALUES
(1, 'felongcoAG', '0fac6a769bfbb90f6329dfecff9113fd', 'Alona', 'Felongco', 'G.');

-- --------------------------------------------------------

--
-- Table structure for table `section_info`
--

CREATE TABLE `section_info` (
  `section_id` int(3) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `specialization_id` int(3) NOT NULL,
  `grade_level` int(2) NOT NULL,
  `classroom_no` varchar(20) NOT NULL,
  `max_population` int(2) NOT NULL,
  `instructor_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section_info`
--

INSERT INTO `section_info` (`section_id`, `section_name`, `specialization_id`, `grade_level`, `classroom_no`, `max_population`, `instructor_id`) VALUES
(13, 'Diamond', 1, 11, 'MAI-102', 49, 1),
(14, 'Pearl', 1, 11, 'MAI-101', 50, 3),
(15, 'Amethyst', 4, 11, 'MAI-103', 50, 4),
(16, 'Emerald', 2, 11, 'ANN-102', 49, 5),
(17, 'Sapphire', 2, 11, 'ANN-101', 50, 6),
(18, 'Crimson', 2, 11, 'ANN-103', 50, 7),
(20, 'Topaz', 3, 12, 'EXT-103', 50, 9),
(21, 'Jasper', 2, 12, 'EXT-101', 49, 10),
(22, 'Garnet', 1, 12, 'MAI-104', 50, 1),
(23, 'Jade', 2, 12, 'EXT-102', 50, 3),
(24, 'Opal', 4, 12, 'EXT-104', 50, 3),
(25, 'Turquoise', 3, 11, 'MAI-103', 50, 6);

-- --------------------------------------------------------

--
-- Table structure for table `specialization_info`
--

CREATE TABLE `specialization_info` (
  `specialization_id` int(3) NOT NULL,
  `specialization_title` varchar(50) NOT NULL,
  `strand_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialization_info`
--

INSERT INTO `specialization_info` (`specialization_id`, `specialization_title`, `strand_id`) VALUES
(1, 'Computer Programming', 1),
(2, 'Automotive Technology', 2),
(3, 'Caregiving', 3),
(4, 'Hotel and Restaurant Services', 3);

-- --------------------------------------------------------

--
-- Table structure for table `strand_info`
--

CREATE TABLE `strand_info` (
  `strand_id` int(3) NOT NULL,
  `strand_title` varchar(50) NOT NULL,
  `track_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `strand_info`
--

INSERT INTO `strand_info` (`strand_id`, `strand_title`, `track_id`) VALUES
(1, 'ICT - Information and Communications Technology', 1),
(2, 'IA - Industrial Arts', 1),
(3, 'HE - Home Economics', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `student_id` int(6) NOT NULL,
  `stud_lrn` varchar(12) NOT NULL,
  `stud_first_name` varchar(30) NOT NULL,
  `stud_last_name` varchar(30) NOT NULL,
  `stud_middle_name` varchar(30) NOT NULL,
  `stud_email` varchar(30) NOT NULL,
  `stud_mobile` varchar(11) NOT NULL,
  `stud_telephone` varchar(13) NOT NULL,
  `stud_address_number` int(5) NOT NULL,
  `stud_fathername` varchar(90) NOT NULL,
  `stud_mothername` varchar(90) NOT NULL,
  `stud_ext_name` varchar(5) NOT NULL,
  `stud_guardian` varchar(90) NOT NULL,
  `stud_age` int(3) NOT NULL,
  `stud_sex` varchar(6) NOT NULL,
  `indigenouspeople_or_cultural` varchar(50) NOT NULL,
  `stud_religion` varchar(30) NOT NULL,
  `stud_birthdate` date NOT NULL,
  `stud_bloodtype` varchar(5) NOT NULL,
  `stud_jrhigh_number` int(5) NOT NULL,
  `stud_picture` blob NOT NULL,
  `stud_status` varchar(15) NOT NULL,
  `section_id` int(2) NOT NULL,
  `stud_gradelevel` int(2) NOT NULL,
  `specialization_id` int(3) NOT NULL,
  `voucher_recipient` int(1) NOT NULL,
  `stud_date_enrolled` date NOT NULL,
  `semester_enrolled` int(1) NOT NULL,
  `school_year_enrolled` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_id`, `stud_lrn`, `stud_first_name`, `stud_last_name`, `stud_middle_name`, `stud_email`, `stud_mobile`, `stud_telephone`, `stud_address_number`, `stud_fathername`, `stud_mothername`, `stud_ext_name`, `stud_guardian`, `stud_age`, `stud_sex`, `indigenouspeople_or_cultural`, `stud_religion`, `stud_birthdate`, `stud_bloodtype`, `stud_jrhigh_number`, `stud_picture`, `stud_status`, `section_id`, `stud_gradelevel`, `specialization_id`, `voucher_recipient`, `stud_date_enrolled`, `semester_enrolled`, `school_year_enrolled`) VALUES
(1, '111222333444', 'Vanessa Kristian', 'Felongco', 'Granada', 'kulitapsq5@gmail.com', '09460975441', '0855252365', 1, 'Andy G. Felongco', 'Alona G. Felongco', '', 'Andy G. Felongco', 19, 'FEMALE', 'None', 'Roman Catholic Christianity', '2000-12-23', 'A ', 1, '', 'Single', 13, 11, 1, 0, '2019-05-06', 1, '2019-2020'),
(2, '2233445566', 'Karla', 'Sison', 'Echalas', 'karla.sison1995@gmail.com', '09216248106', '', 2, 'Carlo Sison', 'Jenet Sison', '', 'Carlo Sison', 24, 'FEMALE', 'Mansaka', 'Atis', '1995-02-18', 'B ', 2, '', 'Single', 16, 11, 2, 1, '2019-05-06', 1, '2019-2020'),
(3, '998877665544', 'Hyacinth Faye', 'Tabasa', 'Aballe', 'hyacinthfayetabasa@gmail.com', '09354161931', '', 3, 'Arnel Tabasa', 'Gillian Faith Tabasa', '', 'Arnel Tabasa', 23, 'FEMALE', 'None', 'Protestant Christianity', '1995-11-08', 'A ', 3, '', 'Single', 21, 12, 2, 0, '2019-05-06', 1, '2019-2020');

-- --------------------------------------------------------

--
-- Table structure for table `stud_address`
--

CREATE TABLE `stud_address` (
  `stud_address_number` int(5) NOT NULL,
  `house_number_street` varchar(50) NOT NULL,
  `subdivision_baranggay` varchar(50) NOT NULL,
  `city_municipality` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `postal_code` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_address`
--

INSERT INTO `stud_address` (`stud_address_number`, `house_number_street`, `subdivision_baranggay`, `city_municipality`, `province`, `country`, `postal_code`) VALUES
(1, 'Purok 7', 'Poblacion', 'Trento', 'Agusan del Sur', 'Philippines', 8505),
(2, '951 N. Torres Ext. cor. Veloso St.', 'Baranggay 20-B', 'Davao', 'Davao del Sur', 'Philippines', 8000),
(3, '951 N. Torres St.', 'Baranggay 20-B', 'Davao City', 'Davao del Sur', 'Philippines', 8000);

-- --------------------------------------------------------

--
-- Table structure for table `subject_info`
--

CREATE TABLE `subject_info` (
  `subject_code` varchar(20) NOT NULL,
  `subject_description` varchar(50) NOT NULL,
  `subject_units` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject_info`
--

INSERT INTO `subject_info` (`subject_code`, `subject_description`, `subject_units`) VALUES
('CPAR', 'Contemporary Philippine Arts from the Regions', 3),
('EAPP', 'English for Academic and Professional Purposes', 3),
('ELS', 'Earth and Life Science', 3),
('FPL', 'Filipino sa Piling Larangan', 3),
('GM', 'General Mathematics', 3),
('IPHP', 'Intro to Philosophy of Human Person', 3),
('IPM', 'Introduction to the Philosophy of Man', 3),
('KPWKP', 'Komunikasyon at Pananaliksik sa Wika at Kulturang ', 3),
('MIL', 'Media and Information Literacy', 3),
('OCC 11', 'Oral Communication in Context', 3),
('PD', 'Personal Development', 3),
('PRII 12', 'Practical Research II', 3);

-- --------------------------------------------------------

--
-- Table structure for table `track_info`
--

CREATE TABLE `track_info` (
  `track_id` int(3) NOT NULL,
  `track_title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `track_info`
--

INSERT INTO `track_info` (`track_id`, `track_title`) VALUES
(1, 'TVL - Technical Vocational and Livelihood');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `campus_info`
--
ALTER TABLE `campus_info`
  ADD PRIMARY KEY (`campus_code`);

--
-- Indexes for table `classroom_info`
--
ALTER TABLE `classroom_info`
  ADD PRIMARY KEY (`classroom_no`),
  ADD KEY `classroom_info_ibfk_1` (`campus_code`);

--
-- Indexes for table `class_assignment`
--
ALTER TABLE `class_assignment`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `instructor_id` (`instructor_id`),
  ADD KEY `subject_code` (`subject_code`),
  ADD KEY `class_assignment_ibfk_5` (`classroom_no`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `class_list`
--
ALTER TABLE `class_list`
  ADD KEY `class_id` (`class_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `department_info`
--
ALTER TABLE `department_info`
  ADD PRIMARY KEY (`department_code`);

--
-- Indexes for table `instructor_info`
--
ALTER TABLE `instructor_info`
  ADD PRIMARY KEY (`instructor_id`),
  ADD KEY `department_code` (`department_code`);

--
-- Indexes for table `jr_high_info`
--
ALTER TABLE `jr_high_info`
  ADD PRIMARY KEY (`stud_jrhigh_number`);

--
-- Indexes for table `registrar_info`
--
ALTER TABLE `registrar_info`
  ADD PRIMARY KEY (`registrar_id`);

--
-- Indexes for table `section_info`
--
ALTER TABLE `section_info`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `section_info_ibfk_3` (`classroom_no`),
  ADD KEY `specialization_id` (`specialization_id`),
  ADD KEY `instructor_id` (`instructor_id`);

--
-- Indexes for table `specialization_info`
--
ALTER TABLE `specialization_info`
  ADD PRIMARY KEY (`specialization_id`),
  ADD KEY `specialization_info_ibfk_1` (`strand_id`);

--
-- Indexes for table `strand_info`
--
ALTER TABLE `strand_info`
  ADD PRIMARY KEY (`strand_id`),
  ADD KEY `track_id` (`track_id`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `section_id` (`section_id`),
  ADD KEY `specialization_id` (`specialization_id`);

--
-- Indexes for table `stud_address`
--
ALTER TABLE `stud_address`
  ADD PRIMARY KEY (`stud_address_number`);

--
-- Indexes for table `subject_info`
--
ALTER TABLE `subject_info`
  ADD PRIMARY KEY (`subject_code`);

--
-- Indexes for table `track_info`
--
ALTER TABLE `track_info`
  ADD PRIMARY KEY (`track_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class_assignment`
--
ALTER TABLE `class_assignment`
  MODIFY `class_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `department_info`
--
ALTER TABLE `department_info`
  MODIFY `department_code` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `instructor_info`
--
ALTER TABLE `instructor_info`
  MODIFY `instructor_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `jr_high_info`
--
ALTER TABLE `jr_high_info`
  MODIFY `stud_jrhigh_number` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registrar_info`
--
ALTER TABLE `registrar_info`
  MODIFY `registrar_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `section_info`
--
ALTER TABLE `section_info`
  MODIFY `section_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `specialization_info`
--
ALTER TABLE `specialization_info`
  MODIFY `specialization_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `strand_info`
--
ALTER TABLE `strand_info`
  MODIFY `strand_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `student_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stud_address`
--
ALTER TABLE `stud_address`
  MODIFY `stud_address_number` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `track_info`
--
ALTER TABLE `track_info`
  MODIFY `track_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classroom_info`
--
ALTER TABLE `classroom_info`
  ADD CONSTRAINT `classroom_info_ibfk_1` FOREIGN KEY (`campus_code`) REFERENCES `campus_info` (`campus_code`) ON UPDATE CASCADE;

--
-- Constraints for table `class_assignment`
--
ALTER TABLE `class_assignment`
  ADD CONSTRAINT `class_assignment_ibfk_2` FOREIGN KEY (`instructor_id`) REFERENCES `instructor_info` (`instructor_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_assignment_ibfk_4` FOREIGN KEY (`subject_code`) REFERENCES `subject_info` (`subject_code`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_assignment_ibfk_5` FOREIGN KEY (`classroom_no`) REFERENCES `classroom_info` (`classroom_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_assignment_ibfk_6` FOREIGN KEY (`section_id`) REFERENCES `section_info` (`section_id`) ON UPDATE CASCADE;

--
-- Constraints for table `class_list`
--
ALTER TABLE `class_list`
  ADD CONSTRAINT `class_list_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class_assignment` (`class_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `class_list_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `student_info` (`student_id`) ON UPDATE CASCADE;

--
-- Constraints for table `instructor_info`
--
ALTER TABLE `instructor_info`
  ADD CONSTRAINT `instructor_info_ibfk_2` FOREIGN KEY (`department_code`) REFERENCES `department_info` (`department_code`) ON UPDATE CASCADE;

--
-- Constraints for table `section_info`
--
ALTER TABLE `section_info`
  ADD CONSTRAINT `section_info_ibfk_3` FOREIGN KEY (`classroom_no`) REFERENCES `classroom_info` (`classroom_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `section_info_ibfk_4` FOREIGN KEY (`specialization_id`) REFERENCES `specialization_info` (`specialization_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `section_info_ibfk_5` FOREIGN KEY (`instructor_id`) REFERENCES `instructor_info` (`instructor_id`) ON UPDATE CASCADE;

--
-- Constraints for table `specialization_info`
--
ALTER TABLE `specialization_info`
  ADD CONSTRAINT `specialization_info_ibfk_1` FOREIGN KEY (`strand_id`) REFERENCES `strand_info` (`strand_id`) ON UPDATE CASCADE;

--
-- Constraints for table `strand_info`
--
ALTER TABLE `strand_info`
  ADD CONSTRAINT `strand_info_ibfk_1` FOREIGN KEY (`track_id`) REFERENCES `track_info` (`track_id`) ON UPDATE CASCADE;

--
-- Constraints for table `student_info`
--
ALTER TABLE `student_info`
  ADD CONSTRAINT `student_info_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `section_info` (`section_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `student_info_ibfk_2` FOREIGN KEY (`specialization_id`) REFERENCES `specialization_info` (`specialization_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
