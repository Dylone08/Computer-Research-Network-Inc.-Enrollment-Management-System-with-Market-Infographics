          </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->
  </div>

  <!-- Bootstrap core JavaScript -->
  <script src="../startbootstrap-simple-sidebar-gh-pages/vendor/jquery/jquery.min.js"></script>
  <script src="../startbootstrap-simple-sidebar-gh-pages/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>



</body>

</html>