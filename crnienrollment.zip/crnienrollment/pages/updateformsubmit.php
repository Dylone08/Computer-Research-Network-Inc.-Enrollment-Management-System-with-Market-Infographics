<?php
include "../includes/dbconfig.php";

//var_dump($_GET);
$studLname= $_GET["studLname"];
$studFname= $_GET["studFname"];
$studMname= $_GET["studMname"];
if (($studMname =="Not Applicable") || ($studMname =="not applicable")||($studMname =="Not applicable")||($studMname =="not Applicable") ||($studMname =="n/a") || ($studMname =="N/a") || ($studMname =="N/A")|| ($studMname =="NONE") || ($studMname =="none") || ($studMname =="None") ) {
	$studMname = "";
}

$studExtname= $_GET["studExtname"];
$studLRN= $_GET["studLRN"];
$studAge= $_GET["studAge"];
$studSex= $_GET["studSex"];
$studBloodType= $_GET["studBloodType"];
$studIP= $_GET["studIP"];
$studReligion= $_GET["studReligion"];
$studStatus= $_GET["studStatus"];

$studHouseNoandStreet= $_GET["studHouseNoandStreet"];
$studSubdBrgy= $_GET["studSubdBrgy"];
$studCityMun= $_GET["studCityMun"];
$studProvince= $_GET["studProvince"];
$studCountry= $_GET["studCountry"];
$studPostal= $_GET["studPostal"];

$studMothersName= $_GET["studMothersName"];
$studFathersName= $_GET["studFathersName"];
$studGuardiansName= $_GET["studGuardiansName"];
$studCellphone= $_GET["studCellphone"];
$studTelephone= $_GET["studTelephone"];
$studEmail= $_GET["studEmail"];

$stud_number = $_GET["studid"];


$createStudAddressQuery = "UPDATE stud_address SET house_number_street = ? , subdivision_baranggay = ? , city_municipality = ? , province = ? , country = ? , postal_code = ? WHERE stud_address_number = ?";
 if($stmt = mysqli_prepare($link, $createStudAddressQuery)){
			mysqli_stmt_bind_param($stmt, "sssssii", $param_house_number_street, $param_subdivision_baranggay, $param_city_municipality, $param_province, $param_country, $param_postal_code, $param_stud_number);
			$param_house_number_street = $studHouseNoandStreet;
			$param_subdivision_baranggay = $studSubdBrgy;
			$param_city_municipality = $studCityMun;
			$param_province = $studProvince;
			$param_country = $studCountry;
			$param_postal_code = $studPostal;
			$param_stud_number = $stud_number;
			if(mysqli_stmt_execute($stmt)){


				mysqli_stmt_close($stmt);
			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}

$createStudInfoQuery= "UPDATE student_info SET stud_lrn = ? , stud_first_name = ?, stud_last_name = ?, stud_middle_name = ?, stud_email = ?, stud_mobile = ?, stud_telephone = ?, stud_fathername = ?, stud_mothername = ?, stud_ext_name = ?, stud_guardian = ?, stud_age = ?, stud_sex = ?, indigenouspeople_or_cultural = ?, stud_religion = ?, stud_bloodtype = ?, stud_status = ?  WHERE student_id = ?";
if($stmt = mysqli_prepare($link, $createStudInfoQuery)){
			mysqli_stmt_bind_param($stmt, "issssssssssisisssi", $param_stud_lrn, $param_stud_first_name, $param_stud_last_name, $param_stud_middle_name, $param_stud_email, $param_stud_mobile, $param_stud_telephone, $param_stud_fathername, $param_stud_mothername, $param_stud_ext_name, $param_stud_guardian, $param_stud_age, $param_stud_sex, $param_indigenouspeople_or_cultural, $param_stud_religion, $param_stud_bloodtype, $param_stud_status,$param_studid);

			$param_stud_lrn= $studLRN;
			$param_stud_first_name= $studFname;
			$param_stud_last_name= $studLname;
			$param_stud_middle_name= $studMname;
			$param_stud_email= $studEmail;
			$param_stud_mobile= $studCellphone;
			$param_stud_telephone= $studTelephone;
			$param_stud_fathername= $studFathersName;
			$param_stud_mothername= $studMothersName;
			$param_stud_ext_name= $studExtname;
			$param_stud_guardian= $studGuardiansName;
			$param_stud_age= $studAge;
			$param_stud_sex= $studSex;
			$param_indigenouspeople_or_cultural= $studIP;
			$param_stud_religion= $studReligion;
			$param_stud_bloodtype= $studBloodType;
			$param_stud_status= $studStatus;
			$param_studid = $stud_number;
			if(mysqli_stmt_execute($stmt)){
				echo "Student information successfully updated!";
				mysqli_stmt_close($stmt);
			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}

?>
