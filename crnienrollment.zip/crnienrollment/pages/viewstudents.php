<?php
include "../includes/crnheader.php";

?>
<?php
if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }

$queryforresultsnum = "SELECT COUNT(*) FROM student_info";
$no_of_records_per_page = 20;
$offset = ($pageno-1) * $no_of_records_per_page; ;
if($stmt2 = mysqli_prepare($link, $queryforresultsnum)){
	if(mysqli_stmt_execute($stmt2)){
		$result = mysqli_stmt_get_result($stmt2);
		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
			$total_rows = $row["COUNT(*)"];
			if ($total_rows == "0") {
				die("No enrollees for this semester and school year yet! Register students first.");
			}

			$total_pages = ceil($total_rows / $no_of_records_per_page);
		}
	}

}

?>
<center>
	<div>
		<h3>Search Students</h3>
	</div>

<form name="searchStudform" method="post" onsubmit="" >
<label>SELECT CRITERIA</label>
<select name = "criteria" onchange="sendquery(document.forms['searchStudform']['studentToSearch'].value, document.forms['searchStudform']['schoolYear'].value, document.forms['searchStudform']['semester'].value, this.value) ;" required>
	<option value=""></option>
	<option value="stud_lrn">Learner Reference Number</option>
	<option value="stud_last_name">Last Name</option>
	<option value="stud_first_name">First Name</option>
	<option value="stud_middle_name">Middle Name</option>
	<option value="stud_ext_name">Extension Name</option>
	<option value="stud_age">Age</option>
	<option value="stud_sex">Sex</option>
	<option value="stud_birthdate">Date of Birth (YYYY-MMM-DD Only)</option>
	<option value="stud_bloodtype">Blood Type</option>
	<option value="indigenouspeople_or_cultural">Indigenous Belonging</option>
	<option value="house_number_street">House Number and Street</option>
	<option value="subdivision_baranggay">Subdivision/Barangay</option>
	<option value="city_municipality">City/Municipality</option>
	<option value="province">Province</option>
	<option value="country">Country</option>
	<option value="postal_code">Postal/Zip Code</option>
	<option value="stud_mothername">Mother's Name</option>
	<option value="stud_fathername">Father's Name</option>
	<option value="stud_fathername">Guardian's Name</option>
	<option value="stud_mobile">Cellphone Number</option>
	<option value="stud_telephone">Telephone Number</option>
	<option value="stud_email">Email Address</option>
	<option value="jrhigh_name">JHS Name</option>
	<option value="jrhigh_address">JHS Address</option>
	<option value="specialization_title">Specialization</option>
</select>
<label>SELECT SCHOOL YEAR</label>
<select name="schoolYear" onchange="sendquery(document.forms['searchStudform']['studentToSearch'].value, this.value , document.forms['searchStudform']['semester'].value , document.forms['searchStudform']['criteria'].value ) ;" required>
<option value=""></option>
		<?php  
		$school_year_array =array();
		$sem_array = array();
		$schoolYearAndSemQuery  = "SELECT school_year_enrolled, semester_enrolled from student_info ORDER BY school_year_enrolled desc";
		if($stmt = mysqli_prepare($link, $schoolYearAndSemQuery)){	
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$sy = $row['school_year_enrolled'];
						$sem= $row['semester_enrolled'];
						array_push($school_year_array, $sy);
						array_push($sem_array, $sem);
						}
				}
							else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}
			$filered_school_year_array = array_unique($school_year_array);
			foreach ($filered_school_year_array as $SYfiltered) {
			echo "<option value=".$SYfiltered.">".$SYfiltered."</option>";
			}

		?>
</select>
<label>SELECT SEMESTER</label>
<select name="semester"  onchange="sendquery(document.forms['searchStudform']['studentToSearch'].value, document.forms['searchStudform']['schoolYear'].value, this.value,  document.forms['searchStudform']['criteria'].value  );" required>
	<option value=""></option>
	<?php
	$filered_sem_array = array_unique($sem_array);
	foreach ($filered_sem_array as $semfiltered) {
	echo "<option value=".$semfiltered.">".$semfiltered."</option>";
	}

	?>
</select><BR/>
<label>TYPE TO SEARCH:</label>
<input type="text" name="studentToSearch" onkeyup="sendquery(this.value, document.forms['searchStudform']['schoolYear'].value, document.forms['searchStudform']['semester'].value,  document.forms['searchStudform']['criteria'].value );">
</form>
	<div id="forallresults" style="display: table;">
	<ul class="pagination">
			<button class="btn btn-success"><li><a href="?pageno=1" style="color: rgb(255,255,255);">First</a></li></button>
	   		<button class="btn btn-success"><li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
	        <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>"style="color: rgb(255,255,255);">Prev</a></li></button>
	    	<button class="btn btn-success"><li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
	        <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>"style="color: rgb(255,255,255);">Next</a>
	   		</li></button>
	    	<button class="btn btn-success"><li><a href="?pageno=<?php echo $total_pages; ?>"style="color: rgb(255,255,255);">Last</a></li></button>
	</ul>
</div>

<div style="overflow-x:auto;">
<table id="forallresultstable" style="font-size: 20px;" class="noborder">
 <thead>
            <tr>
                <th>
                    Learner Reference Number
                </th>
                <th>
                    Last Name
                </th>
                <th>
                    First Name
                </th>
                <th>
                    Middle Name
                </th>
                <th>
                    Extension Name
                </th>
                <th>
                    Age
                </th>
                <th>
                    Sex
                </th>
                <th>
                    Date of Birth
                </th>
                <th>
                    Indigenous Belonging
                </th>
                <th>
                    House Number and Street
                </th>
                <th>
                    Subdivision/Barangay
                </th>
                <th>
                    City/Municipality
                </th>
                <th>
                    Province
                </th>
                <th>
                    Country
                </th>
                <th>
                    Postal/Zip Code
                </th>
                <th>
                    Mother&#x27;s Name
                </th>
                <th>
                    Father&#x27;s Name
                </th>
                <th>
                    Guardian&#x27;s Name
                </th>
                <th>
                    Cellphone Number
                </th>
                <th>
                    Telephone Number
                </th>
                <th>
                    E-mail Address
                </th>
                <th>
                    JHS Name
                </th>
                <th>
                    JHS Address
                </th>
                <th>
                    Specialization
                </th>
                <th> Actions</th>
            </tr>
        </thead>
        <tbody id="studentInfo">
           <?php
           $semester = $filered_sem_array[0];
           $schoolYear = $filered_school_year_array[0];
           $queryforgettingallstudentinfo = "SELECT * FROM jr_high_info  LEFT JOIN (section_info LEFT JOIN (stud_address RIGHT JOIN (student_info LEFT JOIN (specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id=track_info.track_id ) ON specialization_info.strand_id=strand_info.strand_id) ON student_info.specialization_id = specialization_info.specialization_id) ON   stud_address.stud_address_number =student_info.stud_address_number) ON section_info.section_id = student_info.section_id) on jr_high_info.stud_jrhigh_number = student_info.stud_jrhigh_number WHERE school_year_enrolled = ? AND semester_enrolled = ? ORDER BY student_info.student_id DESC LIMIT ?, ?";
            if($stmt1 = mysqli_prepare($link, $queryforgettingallstudentinfo)){
			mysqli_stmt_bind_param($stmt1, "siii",$param_school_year_enrolled1, $param_sem_enrolled1, $param_offset, $param_records_per_page );
			$param_school_year_enrolled1 = $schoolYear;
			$param_sem_enrolled1 = $semester;
			$param_offset = $offset;
			$param_records_per_page = $no_of_records_per_page ;			
			
			if(mysqli_stmt_execute($stmt1)){
				$result = mysqli_stmt_get_result($stmt1);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$student_id = $row["student_id"];
						$studentLRN= $row["stud_lrn"];
						$studentName=$row["stud_first_name"]." ".$row["stud_middle_name"]." ".$row["stud_last_name"]." ".$row["stud_ext_name"];
						$studentFName=$row["stud_first_name"];
						$studentMName=$row["stud_middle_name"];
						$studentLName=$row["stud_last_name"];
						$studentEName=$row["stud_ext_name"];
						$age = $row["stud_age"];
						$sex= $row["stud_sex"];
						$bloodtype= $row["stud_bloodtype"];
						$bday= $row["stud_birthdate"];
						$status = $row["stud_status"];
						$studIP = $row["indigenouspeople_or_cultural"];
						$religion = $row["stud_religion"];
						$address = $row["house_number_street"]." ".$row["subdivision_baranggay"]." ".$row["city_municipality"]." ".$row["province"]." ".$row["country"]." ".$row["postal_code"];
						$house = $row["house_number_street"];
						$subd = $row["subdivision_baranggay"];
						$city_mun = $row["city_municipality"];
						$province = $row["province"];
						$country = $row["country"];
						$postal = $row["postal_code"];

						$studmobile = $row["stud_mobile"];
						$telephone = $row["stud_telephone"];
						$email = $row["stud_email"];
						$mother = $row["stud_mothername"];
						$fathername = $row["stud_fathername"];
						$guardian = $row["stud_guardian"];
						
						$gradelvl= $row["stud_gradelevel"];
						$section= $row["section_name"];
						$specialization = $row["specialization_title"];
						$strand =  $row["strand_title"];
						$track =  $row["track_title"];
						$SY= $row["school_year_enrolled"];
						$sem= $row["semester_enrolled"];
						$voucher = $row["voucher_recipient"];
						$jrhigh_name = $row["jrhigh_name"];
						$jrhigh_address = $row["jrhigh_address"];
						echo "<tr><td>";
				            echo       $studentLRN;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentLName;
				            echo    "</td>";
				            echo    "<td>";
				            echo       $studentFName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentMName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentEName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $age;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $sex;
				            echo    "</td>";
				            echo    "<td>";
				        				$bdate = date_create($bday);
				            echo        date_format($bdate,"M. d, Y");
				            echo    "</th>";
				            echo    "<td>";
				            echo        $studIP;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $house;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $subd;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $city_mun;
				            echo   " </td>";
				            echo    "<td>";
				            echo        $province;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $country;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $postal;
				            echo    "</th>";
				            echo   "<td>";
				            echo        $mother;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $fathername;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $guardian;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studmobile;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $telephone;
				            echo    "</td>";
				            echo    "<td> <a href='mailto: ".$email."'>";
				            echo        $email;
				            echo    "</a></td>";
				            echo    "<td>";
				            echo        $jrhigh_name;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $jrhigh_address;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $specialization;
				            echo    "</td>";
				            echo    "<td><button class='btn btn-success' style='width: 100%;'><a href='readstudentinfo.php?studentName=".$studentName."&student_id=".$student_id."&student_id=".$student_id."&schoolYear=".$schoolYear."&semester=".$semester."' target='_blank'  style='color: rgb(255,255,255)' > READ and UPDATE Profile </a></button></td>";
				        echo    "</tr>";
				}

				mysqli_stmt_close($stmt1);


			}
		 else{
				echo mysqli_error($link);
			}
		}
		else{
				echo mysqli_error($link);

		}
           ?>
        </tbody>
</table>
<table id="resultsTable" style="font-size: 20px;" class="noborder">
</table>
</div></center>

<?php
include "../includes/crnfooter.php";
?>
