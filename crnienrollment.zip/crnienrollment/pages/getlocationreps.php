<?php
include "../includes/dbconfig.php";

$semrep = $_GET["semrep"];
$syrep = $_GET["syrep"];

$getlocationquery = "SELECT city_municipality from student_info LEFT JOIN stud_address ON student_info.stud_address_number=stud_address.stud_address_number WHERE school_year_enrolled = ? AND semester_enrolled = ?";
$city_municipality_array = array();
if($stmt = mysqli_prepare($link, $getlocationquery)){	
			mysqli_stmt_bind_param($stmt, "si", $param_school_year_enrolled, $param_semester_enrolled);
			$param_school_year_enrolled = $syrep;
			$param_semester_enrolled = $semrep;

			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
				 $resultCount = mysqli_num_rows($result);
				 if ($resultCount !=0){
				 	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){

						$city_mun= $row['city_municipality'];
						array_push($city_municipality_array, $city_mun);

						}

$getEnrolleesByLocationQuery = "SELECT COUNT(student_id), city_municipality, province FROM student_info LEFT JOIN stud_address ON student_info.stud_address_number=stud_address.stud_address_number WHERE city_municipality= ? AND school_year_enrolled = ? AND semester_enrolled = ?";
$filered_municipality_array = array_unique($city_municipality_array);
foreach ($filered_municipality_array as $locreports) {

	if($stmt = mysqli_prepare($link, $getEnrolleesByLocationQuery)){	
			mysqli_stmt_bind_param($stmt, "ssi", $param_city_municipality, $param_school_year_enrolled, $param_semester_enrolled);
			$param_city_municipality = $locreports;
			$param_school_year_enrolled = $syrep;
			$param_semester_enrolled = $semrep;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						if ($row["COUNT(student_id)"] != 0 ) {
						echo "<tr>";
						echo "<td>".$row["city_municipality"].", ".$row["province"]."</td>";
						echo "<td>".$row["COUNT(student_id)"]."</td>";
						echo "</tr>";

						}
					}
				}
				else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}

	}


				 }
				 else{
				 	echo "<tr><td>No Enrollees</td></tr>";
				 }
					
				}
							else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}

?>