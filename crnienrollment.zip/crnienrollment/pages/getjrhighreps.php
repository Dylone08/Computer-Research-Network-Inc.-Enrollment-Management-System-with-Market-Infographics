<?php
include "../includes/dbconfig.php";

$semrep = $_GET["semrep"];
$syrep = $_GET["syrep"];

$getjrhighquery = "SELECT jrhigh_name FROM student_info LEFT JOIN jr_high_info on student_info.stud_jrhigh_number=jr_high_info.stud_jrhigh_number WHERE school_year_enrolled = ? AND semester_enrolled = ?";
$jrhigh_array = array();
if($stmt = mysqli_prepare($link, $getjrhighquery)){	
			mysqli_stmt_bind_param($stmt, "si", $param_school_year_enrolled, $param_semester_enrolled);

			$param_school_year_enrolled = $syrep;
			$param_semester_enrolled = $semrep;

			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
				$resultCount = mysqli_num_rows($result);
				 if ($resultCount !=0){
				 	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$jrhigh_name= $row['jrhigh_name'];
						array_push($jrhigh_array, $jrhigh_name);
						}
$getEnrolleesByJRHighQuery = "SELECT COUNT(student_id), jrhigh_name, jrhigh_address FROM student_info LEFT JOIN jr_high_info on student_info.stud_jrhigh_number=jr_high_info.stud_jrhigh_number WHERE jr_high_info.jrhigh_name = ? AND school_year_enrolled = ? AND semester_enrolled = ?;
";
$filered_jrhigh_array = array_unique($jrhigh_array);
foreach ($filered_jrhigh_array as $locreports) {

	if($stmt = mysqli_prepare($link, $getEnrolleesByJRHighQuery)){	
			mysqli_stmt_bind_param($stmt, "ssi", $param_jrhigh_name, $param_school_year_enrolled, $param_semester_enrolled);
			$param_jrhigh_name = $locreports;
			$param_school_year_enrolled = $syrep;
			$param_semester_enrolled = $semrep;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						echo "<tr>";
						echo "<td>".$row["jrhigh_name"].", ".$row["jrhigh_address"]."</td>";
						echo "<td>".$row["COUNT(student_id)"]."</td>";
						echo "</tr>";
						}
				}
				else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}

	}
				 }
				 else{
				 	echo "<tr><td>No Enrollees</td></tr>";
				 }
					
				}
							else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}


?>