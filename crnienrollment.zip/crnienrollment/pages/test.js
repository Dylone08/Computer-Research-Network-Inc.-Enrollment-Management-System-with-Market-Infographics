function validateUpdateForm() {

			var untrimmedstudid = document.forms["updateStudForm"]["studid"].value;
			var untrimmedstudLRN = document.forms["updateStudForm"]["studLRN"].value;
			var untrimmedstudLname = document.forms["updateStudForm"]["studLname"].value;
			var untrimmedstudFname = document.forms["updateStudForm"]["studFname"].value;
			var untrimmedstudMname = document.forms["updateStudForm"]["studMname"].value;
			var untrimmedstudExtname = document.forms["updateStudForm"]["studExtname"].value;

			var untrimmedstudAge = document.forms["updateStudForm"]["studAge"].value;

			var untrimmedstudSex = document.forms["updateStudForm"]["studSex"].value;
			var untrimmedstudBloodType = document.forms["updateStudForm"]["studBloodType"].value;

			var untrimmedstudIP = document.forms["updateStudForm"]["studIP"].value;
			var untrimmedstudOtherReligion = document.forms["updateStudForm"]["studOtherReligion"].value;
			var untrimmedstudReligion = document.forms["updateStudForm"]["studReligion"].value;
			if (untrimmedstudReligion == "others") {
				var untrimmedstudReligion = untrimmedstudOtherReligion.trim();
			}

			var untrimmedstudStatus = document.forms["updateStudForm"]["studStatus"].value;

			var untrimmedstudHouseNoandStreet = document.forms["updateStudForm"]["studHouseNoandStreet"].value;
			var untrimmedstudSubdBrgy = document.forms["updateStudForm"]["studSubdBrgy"].value;			
			var untrimmedstudCityMun = document.forms["updateStudForm"]["studCityMun"].value;
			var untrimmedstudProvince = document.forms["updateStudForm"]["studProvince"].value;
			var untrimmedstudCountry = document.forms["updateStudForm"]["studCountry"].value;
			var untrimmedstudPostal = document.forms["updateStudForm"]["studPostal"].value;

			var untrimmedstudMothersName = document.forms["updateStudForm"]["studMothersName"].value;
			var untrimmedstudFathersName = document.forms["updateStudForm"]["studFathersName"].value;
			var untrimmedstudGuardiansName = document.forms["updateStudForm"]["studGuardiansName"].value;


			var untrimmedstudTelephone = document.forms["updateStudForm"]["studTelephone"].value;
			var untrimmedstudCellphone = document.forms["updateStudForm"]["studCellphone"].value;
			var untrimmedstudTelephone = document.forms["updateStudForm"]["studTelephone"].value;
			var untrimmedstudEmail = document.forms["updateStudForm"]["studEmail"].value;

			var studid = untrimmedstudid.trim();
			var studLRN = untrimmedstudLRN.trim();
			var studLname = untrimmedstudLname.trim();
			var studFname = untrimmedstudFname.trim();
			var studMname = untrimmedstudMname.trim();
			var studExtname = untrimmedstudExtname.trim();

			var studAge = untrimmedstudAge.trim();

			var studSex = untrimmedstudSex.trim();
			var studBloodType = untrimmedstudBloodType.trim();

			var studIP = untrimmedstudIP.trim();

			var studReligion = untrimmedstudReligion.trim();



			var studStatus = untrimmedstudStatus.trim();

			var studHouseNoandStreet = untrimmedstudHouseNoandStreet.trim();
			var studSubdBrgy = untrimmedstudSubdBrgy.trim();			
			var studCityMun = untrimmedstudCityMun.trim();
			var studProvince = untrimmedstudProvince.trim();
			var studCountry = untrimmedstudCountry.trim();
			var studPostal = untrimmedstudPostal.trim();

			var studMothersName = untrimmedstudMothersName.trim();
			var studFathersName = untrimmedstudFathersName.trim();
			var studGuardiansName = untrimmedstudGuardiansName.trim();


			var studCellphone = untrimmedstudCellphone.trim();
			var studTelephone = untrimmedstudTelephone.trim();
			var studEmail = untrimmedstudEmail.trim();


//			document.getElementById('studLRNError').innerHTML = validate(studLRN);
			document.getElementById('LnameError').innerHTML = validate(studLname);
			document.getElementById('FnameError').innerHTML = validate(studFname);
			document.getElementById('MnameError').innerHTML = validate(studMname);

//			document.getElementById('studAgeError').innerHTML = validatenumbers(studAge);

//			document.getElementById('studSexError').innerHTML = validate(studSex);

//			document.getElementById('studIPError').innerHTML = validate(studIP);

			document.getElementById('ReligionError').innerHTML = validate(studReligion);


//			document.getElementById('studBdateError').innerHTML = validate(studBdate);

			document.getElementById('HouseNoandStreetError').innerHTML = validatewithnum(studHouseNoandStreet);
			document.getElementById('SubdBrgyError').innerHTML = validatewithnum(studSubdBrgy);			
			document.getElementById('CityMunError').innerHTML = validate(studCityMun);
			document.getElementById('ProvinceError').innerHTML = validate(studProvince);
			document.getElementById('CountryError').innerHTML = validate(studCountry);
//			document.getElementById('studPostalError').innerHTML = validatenumbers(studPostal);

			document.getElementById('MothersNameError').innerHTML = validateparents(studMothersName);
			document.getElementById('FathersNameError').innerHTML = validateparents(studFathersName);
			document.getElementById('GuardiansNameError').innerHTML = validateparents(studGuardiansName);

			document.getElementById('CellphoneError').innerHTML = validatecellnumbers(studCellphone);
//			document.getElementById('studTelephoneError').innerHTML = validate(studTelephone);
			document.getElementById('EmailError').innerHTML = validateEmail(studEmail);
//			document.getElementById('jrhighCompletionError').innerHTML = validate(jrhighCompletion);

//			document.getElementById('studVoucherError').innerHTML = validate(studVoucher);
if (validate(studLname) == "" && validate(studFname) == "" && validate(studMname) == "" && validate(studReligion) == "" && validatewithnum(studHouseNoandStreet) == "" && validatewithnum(studSubdBrgy) == "" && validate(studCityMun) == "" && validate(studProvince) == "" && validate(studCountry) == "" && validateparents(studMothersName) == "" && validateparents(studFathersName) == "" && validateparents(studGuardiansName) == "" && validatecellnumbers(studCellphone) == "" && validateEmail(studEmail== "") ) {


//			document.getElementById('studSpecializationError').innerHTML = validate(studSpecialization);

				var xmlhttp4 = new XMLHttpRequest();
      		  	xmlhttp4.onreadystatechange = function() {
            		if (this.readyState == 4 && this.status == 200) {

            			alert(this.responseText);        	
            			document.location.reload();
           			}
    	   		};
 				xmlhttp4.open("GET", "updateformsubmit.php?studLname=" + studLname + 
 					"&studFname=" + studFname+
 					"&studMname=" + studMname+
 					"&studExtname=" + studExtname+
 					"&studLRN=" +studLRN+
 					"&studAge="+studAge+
 					"&studSex="+studSex+
 					"&studBloodType="+studBloodType+
 					"&studIP="+studIP+
 					"&studReligion="+studReligion+
 					"&studStatus="+studStatus+
 					"&studHouseNoandStreet="+studHouseNoandStreet+
 					"&studSubdBrgy="+studSubdBrgy+
 					"&studCityMun="+studCityMun+
 					"&studProvince="+studProvince+
 					"&studCountry="+studCountry+
 					"&studPostal="+studPostal+
 					"&studMothersName="+studMothersName+
 					"&studFathersName="+studFathersName+
 					"&studGuardiansName="+studGuardiansName+
 					"&studCellphone="+studCellphone+
 					"&studTelephone="+studTelephone+
 					"&studEmail="+studEmail+
 					"&studid="+studid , true);
       			xmlhttp4.send();


}
else{
	alert("Form fill-up failure! ");
}

			return false;
}