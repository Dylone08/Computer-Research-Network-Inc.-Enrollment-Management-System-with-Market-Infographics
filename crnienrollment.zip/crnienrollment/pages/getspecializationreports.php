<?php
include "../includes/dbconfig.php";

$semrep = $_GET["semrep"];
$syrep = $_GET["syrep"];

$getspecializationquery = "SELECT specialization_id from specialization_info";
$spec_ID_array = array();
if($stmt = mysqli_prepare($link, $getspecializationquery)){	
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$specialization= $row['specialization_id'];
						array_push($spec_ID_array, $specialization);
						}
				}
							else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}

$getEnrolleesBySpecializationQuery = "SELECT COUNT(student_id), specialization_title FROM student_info LEFT JOIN specialization_info ON student_info.specialization_id = specialization_info.specialization_id  WHERE specialization_info.specialization_id= ? AND school_year_enrolled = ? AND semester_enrolled = ?";

$filered_spec_ID_array = array_unique($spec_ID_array);
foreach ($filered_spec_ID_array as $syreports) {

	if($stmt = mysqli_prepare($link, $getEnrolleesBySpecializationQuery)){	
			mysqli_stmt_bind_param($stmt, "isi", $param_specialization_id, $param_school_year_enrolled, $param_semester_enrolled);
			$param_specialization_id = $syreports;
			$param_school_year_enrolled = $syrep;
			$param_semester_enrolled = $semrep;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						echo "<tr>";
						echo "<td>".$row["specialization_title"]."</td>";
						echo "<td>".$row["COUNT(student_id)"]."</td>";
						echo "</tr>";
						}
				}
				else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}

	}
?>