<?php
include "../includes/dbconfig.php";

$semrep = $_GET["semrep"];
$syrep = $_GET["syrep"];

$getgradelevelsquery = "SELECT stud_gradelevel from student_info WHERE school_year_enrolled = ? AND semester_enrolled = ?";
$gradeLevel_array = array();
if($stmt = mysqli_prepare($link, $getgradelevelsquery)){
			mysqli_stmt_bind_param($stmt, "si", $param_school_year_enrolled, $param_semester_enrolled);

			$param_school_year_enrolled = $syrep;
			$param_semester_enrolled = $semrep;

			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
				$resultCount = mysqli_num_rows($result);
				 if ($resultCount !=0){
				 	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$stud_gradelevel= $row['stud_gradelevel'];
						array_push($gradeLevel_array, $stud_gradelevel);
						}
$getEnrolleesByGradeLevelQuery = "SELECT COUNT(student_id) FROM student_info WHERE stud_gradelevel= ? AND school_year_enrolled = ? AND semester_enrolled = ?;
";
$filered_gradeLevel_array = array_unique($gradeLevel_array);
foreach ($filered_gradeLevel_array as $locreports) {

	if($stmt = mysqli_prepare($link, $getEnrolleesByGradeLevelQuery)){	
			mysqli_stmt_bind_param($stmt, "isi", $param_stud_gradelevel, $param_school_year_enrolled, $param_semester_enrolled);
			$param_stud_gradelevel = $locreports;
			$param_school_year_enrolled = $syrep;
			$param_semester_enrolled = $semrep;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						echo "<tr>";
						echo "<td>Grade ".$locreports."</td>";
						echo "<td>".$row["COUNT(student_id)"]."</td>";
						echo "</tr>";
						}
				}
				else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}

	}
				 }
				 else{
				 	echo "<tr><td>No Enrollees</td></tr>";
				 }
					
				}
				else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}


?>