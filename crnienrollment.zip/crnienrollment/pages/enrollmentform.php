<?php
include "../includes/crnheader.php";
?>

<center>
	<div>
		<h3>Enrollment Form</h3>
	</div>
</center>
<main role="main" class="pb-3">
		
<form name="enrollmentForm" method="post" onsubmit="return validateForm(); " >

	<div class="container">


	<div class="row">

	    <div class="col">
			
			<label class="control-label"><b>I. STUDENT INFORMATION</b></label>

		</div>

	</div>

	  <div class="row">

	    <div class="col">
    		
			<label class="control-label">1. LEARNER REFERENCE NUMBER (LRN): </label>
			<div class="form-group">
			<input class="form-control" type="number" name="studLRN" maxlength="12">
			<span id="studLRNError"></span>
			</div>	
			<label class="control-label">2. NAME OF STUDENT*</label>
			<div class="form-group">
			<label class="control-label">LAST*</label>
			<input class="form-control" type="text" name="studLname" maxlength="30" required>
			<span id="studLnameError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">FIRST*</label>
			<input class="form-control" type="text" name="studFname" maxlength="30" required>
			<span id="studFnameError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">MIDDLE (If any. Place "Not Applicable" if none)</label>
			<input class="form-control" type="text" name="studMname" maxlength="30" required >
			<span id="studMnameError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">EXTENSION NAME (If any)</label>
			<input class="form-control" type="text" name="studExtname" maxlength="5" >
			<span id="studExtnameError"></span>
			</div>

	    </div>

	    <div class="col">
	    	<div class="form-group">
			<label class="control-label">3. AGE*</label>
			<input class="form-control" type="number" name="studAge" maxlength="3" required>
			<span id="studAgeError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">4.1. SEX*</label>
			<input type="radio" name="studSex" value="MALE" required> Male
			<input type="radio" name="studSex" value="FEMALE" > Female
			</div>
			<div class="form-group">
			<label class="control-label">4.1. BLOOD TYPE*</label>
			<select class="form-control" class="form-control" name="studBloodType" required>
				<option value=""></option>
				<option value="A+">A+</option>
				<option value="A-">A-</option>
				<option value="B+">B+</option>
				<option value="B-">B-</option>
				<option value="AB+">AB+</option>
				<option value="AB-">AB-</option>
				<option value="O+">O+</option>
				<option value="O-">O-</option>
			</select>
			</div>
			<div class="form-group">
			<label class="control-label">5.1. DATE OF BIRTH*</label>
			<input class="form-control" type="date" name="studBirthDate" required><br>
			<span id="studBdateError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">5.2. Marital Status*</label>
			<select class="form-control" name="studStatus">
			<option value=""></option>
			<option value="Single">Single</option>
			<option value="Married">Married</option>
			<option value="Divorced">Divorced</option>
			<option value="Separated">Separated</option>
			<option value="Widowed">Widowed</option>	
			</select>
			</div>
	    </div>

	    <div class="w-100"><hr></div>

	    <div class="col">
	    	
			<div class="form-group">

			<label class="control-label">6.1 BELONGS TO INDIGENOUS PEOPLES (IP)/ INDIGENOUS CULTURAL (IC) COMMUNITY?*</label>
			<select class="form-control" name="studIP" onchange="showIPfield(this.value);" required>
				<option value=""></option>
				<option value="1">YES</option>
				<option value="0">NO</option>
			</select>
			</div>
			<div class="form-group">		
			<input class="form-control" type="text" name="studspecificIP" id="studspecificIP" placeholder="Please specify indigenous group" maxlength="50" style="display: none; width: 250px;">
			<span id="studIPError"></span>
			</div>

			<div class="form-group">
			<label class="control-label">6.2 RELIGION*</label>
			<select class="form-control" name="studReligion" onchange="otherreligions(this.value);" required>
				<option value=""></option>
				<option value="Iglesia ni Cristo">Iglesia ni Cristo</option>
				<option value="Islam">Islam</option>
				<option value="Protestant Christianity">Protestant Christianity</option>
				<option value="Roman Catholic Christianity">Roman Catholic Christianity</option>
				<option value="others">Others</option>
			</select>
			</div>
			<div class="form-group">
			<input class="form-control" type="text" name="studOtherReligion" id="studOtherReligion" placeholder="Type a Religion" maxlength="30" style="display: none;">
			<span id="studReligionError"></span>
			</div>

			<div class="form-group">
			<label class="control-label">7. PERMANENT HOME ADDRESS*</label>
			<label class="control-label">House Number and Street</label>
			<input class="form-control" type="text" name="studHouseNoandStreet" maxlength="50" required>
			<span id="studHouseNoandStreetError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">Subdivision/Baranggay</label>
			<input class="form-control" type="text" name="studSubdBrgy" maxlength="50" required>
			<span id="studSubdBrgyError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">City/Municipality</label>
			<input class="form-control" type="text" name="studCityMun" maxlength="50" required>
			<span id="studCityMunError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">Province</label>
			<input class="form-control" type="text" name="studProvince" maxlength="50" required>
			<span id="studProvinceError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">Country</label>
			<input class="form-control" type="text" name="studCountry" maxlength="50" required>
			<span id="studCountryError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">Postal/Zip Code</label>
			<input class="form-control" type="number" name="studPostal" maxlength="10" required>
			<span id="studPostalError"></span>
			</div>

	    </div>

	    <div class="col">

	    	<div class="form-group">
			<label class="control-label">8. PARENT/S OR GUARDIAN'S NAME*</label>
			<label class="control-label">Mother's Name: </label>
			<input class="form-control" type="text" name="studMothersName" maxlength="90" required>
			<span id="studMothersNameError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">Father's Name: </label>
			<input class="form-control" type="text" name="studFathersName" maxlength="90" required>
			<span id="studFathersNameError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">Guardian's Name: </label>
			<input class="form-control" type="text" name="studGuardiansName" maxlength="90" required>
			<span id="studGuardiansNameError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">9. CONTACT INFORMATION*</label>
			<label class="control-label">Telephone Number</label>
			<input class="form-control" type="text" name="studTelephone" maxlength="13">
			<label class="control-label">Cellphone Number</label>
			<input class="form-control" type="text" name="studCellphone" minlength ="11" maxlength="11" required>
			<span id="studCellphoneError"></span>
			</div>
			<div class="form-group">
			<label class="control-label">E-mail Address</label>
			<input class="form-control" type="text" name="studEmail" maxlength="30" required>
			<span id="studEmailError"></span>
			</div>

			<div class="form-group">
			<label class="control-label">10. JUNIOR HIGH SCHOOL*</label>
			<label class="control-label">JHS Name (No abbreviations) </label>
			<input class="form-control" type="text" name="jrhighName" maxlength="100" required>
			</div>
			<div class="form-group">
			<span id="jrhighNameError"></span>
			<label class="control-label"><b>Address </b>(City/Municipality, Province and Country)</label>
			<input class="form-control" type="text" name="jrhighAddress" maxlength="100" required>
			</div>
			<div class="form-group">
			<span id="jrhighAddressError"></span>
			<label class="control-label">Month/Year of Completion</label>
			<input class="form-control" type="month" name="jrhighCompletion" required>
			</div>

	    </div>

	    <div class="w-100"><hr></div>

	    <div class="col">

			<div class="form-group">
			<span id="jrhighCompletionError"></span>
			<label class="control-label"><b>II. SENIOR HIGH SCHOOL (SHS) PROGRAM</b></label>
			</div>

			<div class="form-group">
			<label class="control-label">PROGRAM (SPECIALIZATION)</label>
			<select class="form-control" id="studSpecialization" name="studSpecialization" onchange="getSections();" required>
			<option value=""></option>
			<?php  
			$strandquery = "SELECT * from specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id = track_info.track_id) ON specialization_info.strand_id = strand_info.strand_id";
			if($stmt = mysqli_prepare($link, $strandquery)){	
				if(mysqli_stmt_execute($stmt)){
					$result = mysqli_stmt_get_result($stmt);
						while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
							echo "<option value=".$row['specialization_id'].">".$row['specialization_title']." - ".$row['strand_title']." - ".$row['track_title']."</option>";
							}
					}
				}
			?>
			</select>
			<span id="studSpecializationError"></span>
			</div>

			<div class="form-group">
			<label class="control-label">Grade Level WARNING! (Please choose a Specialization FIRST)</label>
				<select class="form-control" name="studGradeLevel" id="studGradeLevel" onchange="getSections();" required>
					<option value=""></option>
					<option value="11">Grade 11</option>
					<option value="12">Grade 12</option>
				</select>
			</div>
			<div class="form-group">
			<label class="control-label">Section</label>
				<select class="form-control" id="studSection" name="studSection" required>
				<option value=""></option>
				</select>
			</div>
			<div class="form-group">
			<label class="control-label">Semester</label>
				<select class="form-control" name="studSem" required>
					<option value=""></option>
					<option value="1">1st</option>
					<option value="2">2nd</option>
				</select>
			</div>
			<div class="form-group">
			<label class="control-label">STUDENT A VOUCHER RECIPIENT?*</label>
				<input type="radio" name="studVoucher" value="1" > YES
				<input type="radio" name="studVoucher" value="0" required> 
			</div>
			<input type="radio" name="agreement" value="agree" required> I understand that all information in this form may be used by the Department of Education and I consent to such with the assurance that personal details will be kept confidential.
			</br></br>
			<div class="button" align="left">
				<button id="button" class="btn btn-success">Submit</button>
			</div>

		</div>

	    <div class="col">
	    	
	    </div>

	  </div>

	</div>

</form>

</div>
</main>

<?php
include "../includes/crnfooter.php";
?>