<?php
include "../includes/crnheader.php";
?>


<center >
	<div style="margin-top: 5px;">
		<h3>Enrollment Reports</h3>
	</div>

<input class="btn btn-success" type="button" value="SPECIALIZATIONS" onclick="openspecializationsreport(); ">
<input class="btn btn-success" type="button" value="LOCATION (MUNICIPALITY)" onclick="openlocationsreport()">
<input class="btn btn-success" type="button" value="JUNIOR HIGH SCHOOL" onclick="openjrhighreport()">
<input class="btn btn-success" type="button" value="GRADE LEVELS" onclick="opengradelevelsreport()">

<div class="selections">
<form name="enrollmentReport" method="post" onsubmit="" >
<label>SELECT SCHOOL YEAR</label>
<select name="schoolYear" onchange="enrollmentreportquery( document.forms['enrollmentReport']['semester'].value, this.value);" required>
		<?php  
		$school_year_array =array();
		$sem_array = array();
		$schoolYearAndSemQuery  = "SELECT school_year_enrolled, semester_enrolled from student_info ORDER BY school_year_enrolled desc";
		if($stmt = mysqli_prepare($link, $schoolYearAndSemQuery)){	
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$sy = $row['school_year_enrolled'];
						$sem= $row['semester_enrolled'];
						array_push($school_year_array, $sy);
						array_push($sem_array, $sem);
						}
				}
							else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}
			$filered_school_year_array = array_unique($school_year_array);
			foreach ($filered_school_year_array as $SYfiltered) {
			echo "<option value=".$SYfiltered.">".$SYfiltered."</option>";
			$mostrecentschoolyear = $filered_school_year_array[0];
			}

		?>
</select>
<label>SELECT SEMESTER</label>
<select name="semester" onchange="enrollmentreportquery(this.value, document.forms['enrollmentReport']['schoolYear'].value );" required>
	<?php
	$SemQuery  = "SELECT DISTINCT semester_enrolled from student_info WHERE school_year_enrolled = ? ORDER BY semester_enrolled desc";
		if($stmt = mysqli_prepare($link, $SemQuery)){	
			mysqli_stmt_bind_param($stmt, "s", $param_sy);
			$param_sy = $mostrecentschoolyear;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$sem= $row['semester_enrolled'];
						array_push($sem_array, $sem);
						}
				}
							else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}

	$filered_sem_array = array_unique($sem_array);
	foreach ($filered_sem_array as $semfiltered) {
	echo "<option value=".$semfiltered.">".$semfiltered."</option>";
	}

	?>
</select> 
</form>
</div>
</center>
<div class="container" id="container">
            <main role="main" class="pb-3">

				<div class="text-center">
				    <h1>Enrollment based on Specializations</h1>
				    <div class="chart-container">
				    <div id="bardiv">
				        <canvas id="bar" style="width:10px; height:400px"></canvas>
				        </div>
				    </div>
				</div>

				<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.min.js"></script>
				<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
				<script type="text/javascript">
				var tbldata = [];
				var bllabels = [];
				var tablename = "";
				        function bars(tbldata, tbllabels , tablename) {
				        	tablename = tablename.charAt(0).toUpperCase() + tablename.slice(1);
				        	tablename = tablename.substring(0, tablename.length - 5);
					    var chartName = "bar";
					    var chardivname = "bardiv";
				        var ctx = document.getElem entById(chartName).getContext('2d');
				        var data = {
				                 labels: tbllabels,
				                datasets: [{
				                    label: "Enrollment Based on "+ tablename,
				                    backgroundColor: [
				                        'rgba(255, 99, 132, 0.2)',
				                        'rgba(54, 162, 235, 0.2)',
				                        'rgba(255, 206, 86, 0.2)',
				                        'rgba(75, 192, 192, 0.2)',
				                        'rgba(153, 102, 255, 0.2)',
				                        'rgba(255, 159, 64, 0.2)',
				                        'rgba(255, 0, 0)',
				                        'rgba(0, 255, 0)',
				                        'rgba(0, 0, 255)',
				                        'rgba(192, 192, 192)',
				                        'rgba(255, 255, 0)',
				                        'rgba(255, 0, 255)'
				                    ],
				                    borderColor: [
				                        'rgba(255,99,132,1)',
				                        'rgba(54, 162, 235, 1)',
				                        'rgba(255, 206, 86, 1)',
				                        'rgba(75, 192, 192, 1)',
				                        'rgba(153, 102, 255, 1)',
				                        'rgba(255, 159, 64, 1)',
				                        'rgba(255, 0, 0)',
				                        'rgba(0, 255, 0)',
				                        'rgba(0, 0, 255)',
				                        'rgba(192, 192, 192)',
				                        'rgba(255, 255, 0)',
				                        'rgba(255, 0, 255)'
				                    ],
				                    borderWidth: 1,
				                    data: tbldata
				    }]
				            };
				var options = {
				                maintainAspectRatio: false,
				                scales: {
				                    yAxes: [{
				                        ticks: {
				                            min: 0,
				                            beginAtZero: true
				                        },
				                        gridLines: {
				                            display: true,
				                            color: "rgba(255,99,164,0.2)"
				                        }
				}],
				                    xAxes: [{
				                        ticks: {
				                            min: 0,
				                            beginAtZero: true
				                        },
				                        gridLines: {
				                            display: false
				                        }
				                    }]
				                }
				            };
					     if (document.getElementById(chardivname).chart && document.getElementById(chardivname).chart !==null) {
					    	document.getElementById(chardivname).chart.destroy();
					    }

				       document.getElementById(chardivname).chart = new  Chart(ctx, {
				                options: options,
				                data: data,
				                type:'bar'
				            });
				        }
				</script>

				<div class="text-center">
					<h1>Enrollment Distribution</h1>
				    <div class="chart-container">
				    <div id="piediv">
				        <canvas id="pie" style="width:10px; height:400px"></canvas>
				        </div>
				    </div>
				</div>

				<script type="text/javascript">

				        function pies(tbldata, tbllabels, tablename) {
					    var chartName = "pie";
					    var chardivname = "piediv";
				        	tablename = tablename.charAt(0).toUpperCase() + tablename.slice(1);
				        	tablename = tablename.substring(0, tablename.length - 5);
				        var ctx = document.getElementById(chartName).getContext('2d');
				        var data = {
				                labels: tbllabels,
				                datasets: [{
				                    label: "Enrollment Based on "+ tablename,
				                    backgroundColor: [
				                        'rgba(255, 99, 132, 0.2)',
				                        'rgba(54, 162, 235, 0.2)',
				                        'rgba(255, 206, 86, 0.2)',
				                        'rgba(75, 192, 192, 0.2)',
				                        'rgba(153, 102, 255, 0.2)',
				                        'rgba(255, 159, 64, 0.2)',
				                        'rgba(255, 0, 0)',
				                        'rgba(0, 255, 0)',
				                        'rgba(0, 0, 255)',
				                        'rgba(192, 192, 192)',
				                        'rgba(255, 255, 0)',
				                        'rgba(255, 0, 255)'
				                    ],
				                    borderColor: [
				                        'rgba(255,99,132,1)',
				                        'rgba(54, 162, 235, 1)',
				                        'rgba(255, 206, 86, 1)',
				                        'rgba(75, 192, 192, 1)',
				                        'rgba(153, 102, 255, 1)',
				                        'rgba(255, 159, 64, 1)',
				                        'rgba(255, 0, 0)',
				                        'rgba(0, 255, 0)',
				                        'rgba(0, 0, 255)',
				                        'rgba(192, 192, 192)',
				                        'rgba(255, 255, 0)',
				                        'rgba(255, 0, 255)'
				                    ],
				                    borderWidth: 1,
				                    data: tbldata
				    }]
				            };

				var options = {
				                maintainAspectRatio: false,
				                scales: {
				                    yAxes: [{
				                        ticks: {
				                            min: 0,
				                            beginAtZero: true
				                        },
				                        gridLines: {
				                            display: true,
				                            color: "rgba(255,99,164,0.2)"
				                        }
				}],
				                    xAxes: [{
				                        ticks: {
				                            min: 0,
				                            beginAtZero: true
				                        },
				                        gridLines: {
				                            display: false
				                        }
				                    }]
				                }
				            };

				       if (document.getElementById(chardivname).chart && document.getElementById(chardivname).chart !==null) {
					    	document.getElementById(chardivname).chart.destroy();
					    }

				       document.getElementById(chardivname).chart = new  Chart(ctx, {
				                options: options,
				                data: data,
				                type:'pie'
				            });
				        }
				</script>  

<!--

			<div class="text-center">
			    <div class="chart-container">
			    	<h1>Line Graph Visualization</h1>  
				    <div id="linediv">
		            <canvas id="line" style="width:100%; height:400px"></canvas>  
		            </div>
			    </div>
		    </div>   
	  
			<script type="text/javascript">  
				        function lines(tbldata, tbllabels, tablename) {
			    var chartName = "line";  
					    var chardivname = "linediv";
			        var ctx = document.getElementById(chartName).getContext('2d');  
			        var data = {  
				                labels: tbllabels,
			                datasets: [{  
			                    label: "Line Graph Visualization",  
			                    backgroundColor: [  
			                        'rgba(255, 99, 132, 0.2)',  
			                    ],  
			                    borderColor: [  
			                        'rgba(255,99,132,1)',   
			                    ],  
			                    borderWidth: 1,  
				                    data: tbldata
			    }]  
			            };  
			  
			var options = {

							elements: {
					            line: {
					                tension: 0 // disables bezier curves
					            }
					        },


			                maintainAspectRatio: false,  
			                scales: {  
			                    yAxes: [{  
			                        ticks: {  
			                            min: 0,  
			                            beginAtZero: true  
			                        },  
			                        gridLines: {  
			                            display: true,  
			                            color: "rgba(255,99,164,0.2)"  
			                        }  
			}],  
			                    xAxes: [{  
			                        ticks: {  
			                            min: 0,  
			                            beginAtZero: true  
			                        },  
			                        gridLines: {  
			                            display: false  
			                        }  
			                    }]  
			                }

						

			            };  
			  
			       if (document.getElementById(chardivname).chart && document.getElementById(chardivname).chart !==null) {
					    	document.getElementById(chardivname).chart.destroy();
					    }

				       document.getElementById(chardivname).chart = new  Chart(ctx, {
				                options: options,
				                data: data,
				                type:'line'
				            });
			        }  
			</script> 

		-->

		<div class="text-center">
			    <div class="chart-container">
			    	<h1>3 Year Enrollment Report</h1>  
		            <canvas id="line" style="width:100%; height:400px"></canvas>  
			    </div>
		    </div>   
	  
			<script type="text/javascript">  
				        function lines(tbldata, tbllabels, tablename) {
			    var chartName = "line";  
		    			tablename = tablename.charAt(0).toUpperCase() + tablename.slice(1);
			        	tablename = tablename.substring(0, tablename.length - 5);
			        var ctx = document.getElementById(chartName).getContext('2d');  
			        var data = {  
				                labels: ["","","2017-2018","2018-2019","2019-2020",""],
			                datasets: [{  
			                    label: "Enrollment based on " + tablename,  
			                    backgroundColor: [  
			                        'rgba(255, 99, 132, 0.2)',  
			                    ],  
			                    borderColor: [  
			                        'rgba(255,99,132,1)',   
			                    ],  
			                    borderWidth: 1,  
				                    data: [0,0,215,278,329,0]
			    }]  
			            };  
			  
			var options = {

							elements: {
					            line: {
					                tension: 0 // disables bezier curves
					            }
					        },


			                maintainAspectRatio: false,  
			                scales: {  
			                    yAxes: [{  
			                        ticks: {  
			                            min: 0,  
			                            beginAtZero: true  
			                        },  
			                        gridLines: {  
			                            display: true,  
			                            color: "rgba(255,99,164,0,2)"  
			                        }  
			}],  
			                    xAxes: [{  
			                        ticks: {  
			                            min: 0,  
			                            beginAtZero: true  
			                        },  
			                        gridLines: {  
			                            display: false  
			                        }  
			                    }]  
			                }

						

			            };  
			  
			       var myChart = new  Chart(ctx, {  
			                options: options,  
			                data: data,  
			                type:'line'  
			  
			            });  
			        }  
			</script>

    	</main>
	</div>


    <footer class="border-top footer text-muted">
        <div class="container">
            &copy; 2019 - CRNI Enrollment System - <a href="">Privacy</a>
        </div>
    </footer>

<center>
<div  class="grid-container" id="allreports" style="margin-right: 20px;">

<div class="card"  id="specializations" onclick =" return getspecializationreps(document.forms['enrollmentReport']['semester'].value, document.forms['enrollmentReport']['schoolYear'].value);">

	<div>
	<table class="noborder"  id="specializationstable" >
	<tr id="specheading" style="display: none;">
		<th>Specializations</th>
		<th>Enrollees</th>
	</tr>
	</table>
	</div>
  <div class="container">
    <h5>Specialization</h5> 
  </div>
</div>


<div class="card" id="locations" onclick =" return getlocationreps(document.forms['enrollmentReport']['semester'].value, document.forms['enrollmentReport']['schoolYear'].value);" >
	<div>
	<table id="locationstable">
	</table>
	</div>
  <div class="container">
    <h5>Location</h5> 
  </div>
</div>


<div class="card"  id="jrhigh" onclick =" return getjrhighreps(document.forms['enrollmentReport']['semester'].value, document.forms['enrollmentReport']['schoolYear'].value);" >
	<div>
	<table id="jrhightable">
	</table>
	</div>
  <div class="container">
    <h5>Junior High</h5> 
  </div>
</div>


<div class="card"  id="gradelevels" onclick =" return getgradelevelreps(document.forms['enrollmentReport']['semester'].value, document.forms['enrollmentReport']['schoolYear'].value);" >
	<div>
	<table id="gradelevelstable">
	</table>
	</div>
  <div class="container">
    <h5>Grade Levels</h5> 
  </div>
</div>

	
</div>

</center>
<script type="text/javascript">
	body.onload=openspecializationsreport();
</script>
<?php
include "../includes/crnfooter.php";
?>
