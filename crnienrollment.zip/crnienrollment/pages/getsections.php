<?php
include "../includes/dbconfig.php";

$gradelevel = $_GET['gradelevel']; 
$specializationID = $_GET["specializationID"];
$readSectionNameQuery = "SELECT * FROM section_info WHERE grade_level = '$gradelevel' AND specialization_id = '$specializationID' AND max_population >0 ";

if ($result = mysqli_query($link,$readSectionNameQuery)) {
	if (mysqli_num_rows($result) == 0) {
		if (!empty($gradelevel) && !empty($specializationID)) {
	echo "<option value=''>No Sections Available. Please change Grade Level or Specialization.</option>";
		}
		else{
			echo "<option value=''option>";
	
		}
	}
	else{
		echo "<option value=''></option>";
		while( $row = mysqli_fetch_array($result) ){
		echo "<option value = \"".$row{'section_id'}."\">" . $row{'section_name'} . "</option>";
}		
	}


}
else{
	die(mysqli_error($link));
}
?>