<?php
include "../includes/dbconfig.php";
session_start();
if (!isset($_SESSION["crniregistrarusername"]) || empty($_SESSION["crniregistrarusername"])) {
  header("Location:log-in.php");
}

?>
<?php

$studentID= $_GET["studentNumber"];
$SY_enrolled = $_GET["school_year_enrolled"];
$sem_enrolled = $_GET["sem_enrolled"];
$getStudInfoquery = "SELECT * FROM student_info LEFT JOIN specialization_info ON student_info.specialization_id = specialization_info.specialization_id WHERE student_id=? AND school_year_enrolled= ? AND semester_enrolled= ? ";

 if($stmt = mysqli_prepare($link, $getStudInfoquery)){
			mysqli_stmt_bind_param($stmt, "isi", $param_studentID1, $param_school_year_enrolled1, $param_sem_enrolled1);
			$param_studentID1 = $studentID;
			$param_school_year_enrolled1 = $SY_enrolled;
			$param_sem_enrolled1 = $sem_enrolled;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$studentName=$row["stud_first_name"]." ".$row["stud_middle_name"]." ".$row["stud_last_name"]." ".$row["stud_ext_name"];
						$specialization = $row["specialization_title"];
						$voucher_recipient = $row["voucher_recipient"];
				}

				mysqli_stmt_close($stmt);


			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Statement of Accounts</title>
<style type="text/css">
	@media print and (width: 4in) and (height: 6.5in) {
	 @page {
	 margin: 1in;
	 }
	}
</style>
</head>
<body>
<center>
	<img src="../images/CRNI logo.jpg" style="width: 10%">
	<h2>COMPUTER RESEARCH NETWORK (CRN), INC</h2>
<p>Trento, Agusan del Sur</p>
	<h3>STATEMENT OF ACCOUNTS</h3>
</center>
<center>

<?php
if ($voucher_recipient == 1) {
	?>
<div id="toPrint">
	<table>
		<tr>
			<td>Name:</td>
			<td><?php echo $studentName; ?></td>
		</tr>
		<tr>
			<td>Specialization:</td>
			<td><?php echo $specialization; ?></td>
		</tr>
		<tr>
			<td>Date:</td>
			<td><?php echo date('F d, Y'); ?></td>
		</tr>
		<tr>
			<td>Total Accounts:</td>
			<td>PhP 0.00</td>
		</tr>
		<tr>
			<td>Total DUe to Date::</td>
			<td>PhP 0.00</td>
		</tr>
		<tr>
			<td>Partial Payments::</td>
			<td>PhP 0.00</td>
		</tr>
		<tr>
			<td>Balance:</td>
			<td>PhP 0.00</td>
		</tr>
		<tr>
			<td>Amount Due:</td>
			<td>PhP 0.00</td>
		</tr>
		<tr>
			<td>Due Date:</td>
			<td>Not Applicable</td>
		</tr>
	</table>
	<br/>
	<br/>
	<br/>
	<table style="text-align: center;">
	<tr>
	<td  style="padding-right: 30px;">
			<label>Noted by:</label><br/>
			<br/>
			<br/>
			<br/>
			<u>_______________</u>
			<p>Cashier</p>
	</td>
	</td>
	<td style="padding-left: 30px;">
		<label>Verified by:</label><br/>
			<br/>
			<br/>
			<br/>
			<u>Alona G. Felongco</u>
			<p>Registrar</p>
	</td>
	</tr>
	</table>
</div>
	<div id="noPrint">
		<button onclick="printPage();">PRINT</button>
	</div>

	<?php
}
else{



?>
	</center>
<div style="padding-left: 500px;" id="paymentform">
<form name="paymentform" method="post" onsubmit="return showSOA();">
			<label>Name:</label>
			<label><?php echo $studentName; ?></label><br/>
			<label>Specialization:</label>
			<label><?php echo $specialization; ?></label><br/>
			<label>Total Accounts:</label>
			<label>PhP 5,000.00</label><br/>
			<label>Total due to date:</label>
			<label>PhP 0.00</label><br/>
			<label>Partial Payments: PhP </label>
			<input type="number" name="partialPayments" onkeyup="deduct(this.value);"><br/>
			<label>Balance:</label>
			<input type="text" id="acctBal" name="acctBal" readonly><br/>
			<label>Amount Due:</label>
			<input type="text" id="acctAmtDue" name="acctAmtDue" readonly><br/>
			<label>Due Date:</label>
			<label><i>To be noted by Cashier</i></label><br/>
			<div class="button"><button>Submit</button></div>

</form>
</div>
<center>
<div id="toPrint">
<div id="toPrintforNonVoucherRecipient" hidden>
		<table>
		<tr>
			<td>Name:</td>
			<td><?php echo $studentName; ?></td>
		</tr>
		<tr>
			<td>Specialization:</td>
			<td><?php echo $specialization; ?></td>
		</tr>
		<tr>
			<td>Date:</td>
			<td><?php echo date('F d, Y'); ?></td>
		</tr>
		<tr>
			<td>Total Accounts:</td>
			<td>PhP 5000.00</td>
		</tr>
		<tr>
			<td>Total Due to Date:</td>
			<td>PhP 0.00</td>
		</tr>
		<tr>
			<td>Partial Payments:</td>
			<td id="partial">PhP 0.00</td>
		</tr>
		<tr>
			<td>Balance:</td>
			<td id="balance">PhP 0.00</td>
		</tr>
		<tr>
			<td>Amount Due:</td>
			<td id="amtdue">PhP 0.00</td>
		</tr>
		<tr>
			<td>Due Date:</td>
			<td>Not Applicable</td>
		</tr>
	</table>
	<br/>
	<br/>
	<br/>
	<table style="text-align: center;">
	<tr>
	<td  style="padding-right: 30px;">
			<label>Noted by:</label><br/>
			<br/>
			<br/>
			<br/>
			<u>_______________</u>
			<p>Cashier</p>
	</td>
	</td>
	<td style="padding-left: 30px;">
		<label>Verified by:</label><br/>
			<br/>
			<br/>
			<br/>
			<u>Alona G. Felongco</u>
			<p>Registrar</p>
	</td>
	</tr>
	</table>
	<div id="noPrint">
		<button onclick="printPage();">PRINT</button>
	</div>

</div>
</div>
</center>
<script type="text/javascript">
	function deduct(payment){
        document.getElementById("acctBal").value =5000-payment;	
        document.getElementById("acctAmtDue").value =(5000-payment)/4;
        document.getElementById("partial").innerHTML = payment;
        document.getElementById("balance").innerHTML= 5000-payment;
        document.getElementById("amtdue").innerHTML= (5000-payment)/4;

	}
	function showSOA(){
		document.getElementById('toPrintforNonVoucherRecipient').style.display="block";
		document.getElementById('paymentform').style.display="none";
		return false;
	}
	function printPage(){
		document.getElementById("noPrint").style.display="none";
		window.print();
		document.getElementById("noPrint").style.display="block";
	}
</script>
<?php
}
?>

</body>
</html>