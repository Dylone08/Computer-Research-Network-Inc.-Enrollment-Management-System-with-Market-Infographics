<?php
session_start();
include "../includes/dbconfig.php";

$reg_username = $_GET["crni_reg_username"];
$unencryptedpass = $_GET["crni_reg_password"];
$reg_password = md5($unencryptedpass);


$validateloginquery = "SELECT * FROM registrar_info WHERE registrar_username = ? AND registrar_pass = ?";

if($stmt = mysqli_prepare($link, $validateloginquery)){
			mysqli_stmt_bind_param($stmt, "ss", $_param_registrar_username, $_param_registrar_pass);
			$_param_registrar_username = $reg_username;
			$_param_registrar_pass = $reg_password;

			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
				$resultCount = mysqli_num_rows($result);
				 if ($resultCount !=0){
				 	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
				 		$_SESSION["crniregistrarusername"] = $row["registrar_username"];
				 		$_SESSION["crniregistrarfirstname"] = $row["registrar_fname"];
				 		$_SESSION["crniregistrarlastname"] = $row["registrar_lname"];
				 		$_SESSION["crniregistrarmiddlename"] = $row["registrar_mname"];
				 	}
				 	echo "Log-in successful!";

				 }
				 else{
				 	echo "Incorrect username or password!";
				 }
			}
				else{
				die(mysqli_error($link));
			}

			}
			else{
				die(mysqli_error($link));
			}


		
?>