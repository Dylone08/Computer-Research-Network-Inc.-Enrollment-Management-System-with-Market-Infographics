<?php
session_start();

unset($_SESSION["crniregistrarusername"]);
unset($_SESSION["crniregistrarfirstname"]);
unset($_SESSION["crniregistrarlastname"]);
unset($_SESSION["crniregistrarmiddlename"]);

session_destroy();
echo "Logging out";
?>