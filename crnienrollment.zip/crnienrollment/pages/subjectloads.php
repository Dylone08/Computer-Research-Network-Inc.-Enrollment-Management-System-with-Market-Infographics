<?php
include "../includes/dbconfig.php";

session_start();
if (!isset($_SESSION["crniregistrarusername"]) || empty($_SESSION["crniregistrarusername"])) {
  header("Location:log-in.php");
}

$studentID = $_GET["studentNumber"];
$school_year_enrolled =$_GET["school_year_enrolled"];
$sem_enrolled =$_GET["sem_enrolled"];
$queryforgettingstudentinfo = "SELECT * FROM section_info LEFT JOIN (stud_address RIGHT JOIN (student_info LEFT JOIN (specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id=track_info.track_id ) ON specialization_info.strand_id=
strand_info.strand_id) ON student_info.specialization_id = specialization_info.specialization_id) ON   stud_address.stud_address_number =student_info.stud_address_number) ON section_info.section_id = student_info.section_id WHERE student_id = ? AND school_year_enrolled = ? AND semester_enrolled = ? ";
 if($stmt1 = mysqli_prepare($link, $queryforgettingstudentinfo)){
			mysqli_stmt_bind_param($stmt1, "isi", $param_studentID1, $param_school_year_enrolled1, $param_sem_enrolled1);
			$param_studentID1 = $studentID;
			$param_school_year_enrolled1 = $school_year_enrolled;
			$param_sem_enrolled1 = $sem_enrolled;
			if(mysqli_stmt_execute($stmt1)){
				$result = mysqli_stmt_get_result($stmt1);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$studentLRN= $row["stud_lrn"];
						$studentName=$row["stud_first_name"]." ".$row["stud_middle_name"]." ".$row["stud_last_name"]." ".$row["stud_ext_name"];
						$age = $row["stud_age"];
						$bday= $row["stud_birthdate"];
						$address = $row["house_number_street"]." ".$row["subdivision_baranggay"]." ".$row["city_municipality"]." ".$row["province"]." ".$row["country"]." ".$row["postal_code"];
						$studmobile = $row["stud_mobile"];
						$gradelvl= $row["stud_gradelevel"];
						$section= $row["section_name"];
						$specialization = $row["specialization_title"];
						$strand =  $row["strand_title"];
						$track =  $row["track_title"];
						$SY= $row["school_year_enrolled"];
						$sem= $row["semester_enrolled"];
				}

				mysqli_stmt_close($stmt1);


			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Subject Load</title>
	<style type="text/css">
	</style>
</head>
<body>
<center>
	<p>Department of Education</p>
	<h3>COMPUTER RESEARCH NETWORK (CRN), INC</h3>
	<h2>Senior High School Enrolment Form</h3>
</center>
	<div>
	<table>
	<tr>
	<td id="noborder">
		<label>NAME:</label>
		<b><?php echo $studentName; ?></b>
		<label>STUDENT LRN:</label>
		<?php echo $studentLRN; ?><br>
		</td>
		</tr>
		<tr>
		<td>
		<label>SECTION:</label>
		<?php echo $section; ?>
		<label>GRADE LEVEL:</label>
		<?php echo $gradelvl; ?><br/>
		<label>SPECIALIZATION:</label>
		<?php echo $specialization; ?><br/>
		<label>TRACK:</label>
		<?php echo $track; ?>
		<label>STRAND:</label>
		<?php echo $strand; ?><br/>
		<label>SY and SEMESTER:</label>
		<?php echo $SY." Semester number ".$sem; ?>		
		</td>
		<td>
		<label>AGE:</label>
		<?php echo $age; ?>
		<label>BIRTHDATE:</label>
		<?php echo $bday; ?><br/>
		<label>CONTACT NUMBER:</label>
		<?php echo $studmobile; ?><br/>
		<label>ADDRESS:</label>
		<?php echo $address; ?>
		</td>
	</tr>
	</table>
	</div>
	<br/>
	<br/>
	<br/>	
	<center>
	<table style="width: 80%; border-color: black;">
	<tr>
	<th>SUBJECT CODE</th>
	<th>SUBJECT TITLE</th>
	<th>CLASSROOM</th>
	<th>INSTRUCTOR</th>
	<th>UNITS</th>
	</tr>

	<?php
$queryforgettingsubjectload = "SELECT * FROM student_info LEFT JOIN (class_list LEFT JOIN (instructor_info RIGHT JOIN (class_assignment LEFT JOIN subject_info on class_assignment.subject_code = subject_info.subject_code) ON instructor_info.instructor_id = class_assignment.instructor_id) ON class_list.class_id = class_assignment.class_id) ON student_info.student_id = class_list.student_id WHERE student_info.student_id= ? AND school_year_enrolled = ? AND semester_enrolled = ?";
 if($stmt = mysqli_prepare($link, $queryforgettingsubjectload)){
			mysqli_stmt_bind_param($stmt, "isi", $param_studentID, $param_school_year_enrolled, $param_sem_enrolled);
			$param_studentID = $studentID;
			$param_school_year_enrolled = $school_year_enrolled;
			$param_sem_enrolled = $sem_enrolled;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						echo "<tr>";
						echo "<td id='noborder'>".$row['subject_code']."</td>";
						echo "<td id='noborder'>".$row['subject_description']."</td>";
						echo "<td id='noborder'>".$row['classroom_no']."</td>";
						echo "<td id='noborder'>".$row['inst_fname']." ".$row['inst_mname']." ".$row['inst_lname']."</td>";
						echo "<td id='noborder'>".$row['subject_units']."</td>";
						echo "</tr>";
						//echo "<td>".$row['student_id']."</td>";
					//	echo "<td>".$row['student_id']."</td>";
					//	echo "<td>".$row['student_id']."</td>";
					//	echo "<td>".$row['student_id']."</td>";
					
					}

				mysqli_stmt_close($stmt);


			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}	?>
			</table>

			<label>Verified by:</label><br/>
			<br/>
			<br/>
			<br/>
			<u>Alona G. Felongco</u>
			<p>Registrar</p>

	<div id="notToPrint">
		<button onclick="printPage();">PRINT</button>
	</div>
<script type="text/javascript">
	function printPage(){
		document.getElementById("notToPrint").style.display="none";
		window.print();
		document.getElementById("notToPrint").style.display="block";
	}
</script>
</center>
</body>
</html>