<?php
session_start();

if (isset($_SESSION["crniregistrarusername"])) {
	header("Location:index.php");
}
  ?>
<html>
<head>
<title>CRNI Log-in</title>
<link rel="stylesheet" href="css/style.css"/>
<script src="../javascript/jsfunctions.js"></script>
  <link href="../startbootstrap-simple-sidebar-gh-pages/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../styles/tablesstyle.css" rel="stylesheet">
  <link rel="shortcut icon" href="../images/CRNI favicon.jpg" />
    <style type="text/css">
    	body{
    	background-image: url("../images/CRNI logo70opacity.png"), url("../images/Department_of_Education_(DepEd).png");
    	background-repeat: no-repeat;
    	background-position: left, right;
    	background-size: 40%;
    	color: #009900;
    	font-family: Arial;
    	font-weight: bold;
    	text-shadow:
		-1px -1px 0 #000,
		1px -1px 0 #000,
		-1px 1px 0 #000,
		1px 1px 0 #000;
    	}
    </style>
</head>
<body>
<center>
<div>
<h3 style="margin-top: 50px;" >COMPUTER RESEARCH NETWORK (CRN), INC</h3>
</div>
<div class="login-page">
<div class="form">
<h2>Registrar Log-in</h2><br/>
<form id="crniLogInForm" class="register-form" method="post" name="crniLogInForm" onsubmit="return validateLogin();">
<input type="text" name="registrarUsername"  placeholder="Username" id="registrarUsername" required/><br/>
<span id="usernameError"></span><br/>
<input type="password"  name="registrarPassword" placeholder="password" id="registrarPassword" required/><br/>
<span id="passwordError"></span><br/><br/>
<button >Submit</button>
<br/><br/>
<!--
<a style="color: black;font-weight: normal;text-shadow: none;" href="login_admin.php">Login as Administrator</a>
-->
</form>
</div>
</div>
</center>
</body>
</html>
