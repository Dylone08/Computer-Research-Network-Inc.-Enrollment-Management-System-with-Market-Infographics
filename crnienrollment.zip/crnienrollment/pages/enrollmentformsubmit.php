<?php
include "../includes/dbconfig.php";

//var_dump($_GET);
$studLname= $_GET["studLname"];
$studFname= $_GET["studFname"];
$studMname= $_GET["studMname"];

if ( $studMname =="Not Applicable"  ||  $studMname =="not applicable" || $studMname =="Not applicable" || $studMname =="not Applicable"  || $studMname =="n/a"  ||  $studMname =="N/a"  ||  $studMname =="N/A" ||  $studMname =="NONE"  ||  $studMname =="none"  ||  $studMname =="None"  ) {
	$studMname = "";
}

$studExtname= $_GET["studExtname"];
$studLRN= $_GET["studLRN"];
$studAge= $_GET["studAge"];
$studSex= $_GET["studSex"];
$studBloodType= $_GET["studBloodType"];
$studIP= $_GET["studIP"];
$studReligion= $_GET["studReligion"];
$studBdate= $_GET["studBdate"];
$studStatus= $_GET["studStatus"];

$studHouseNoandStreet= $_GET["studHouseNoandStreet"];
$studSubdBrgy= $_GET["studSubdBrgy"];
$studCityMun= $_GET["studCityMun"];
$studProvince= $_GET["studProvince"];
$studCountry= $_GET["studCountry"];
$studPostal= $_GET["studPostal"];

$studMothersName= $_GET["studMothersName"];
$studFathersName= $_GET["studFathersName"];
$studGuardiansName= $_GET["studGuardiansName"];
$studCellphone= $_GET["studCellphone"];
$studTelephone= $_GET["studTelephone"];
$studEmail= $_GET["studEmail"];

$jrhighName= $_GET["jrhighName"];
$jrhighAddress= $_GET["jrhighAddress"];
$jrhighCompletion= $_GET["jrhighCompletion"];

$studSpecialization= $_GET["studSpecialization"];
$studGradeLevel= $_GET["studGradeLevel"];
$studSection= $_GET["studSection"];
$studSem= $_GET["studSem"];
$studEnrollDate= $_GET["studEnrollDate"];
$studSY= $_GET["studSY"];
$studVoucher= $_GET["studVoucher"];

$stud_number = "";

$checkifstudentalreadyexistsquery = "SELECT COUNT(student_id) FROM student_info WHERE stud_lrn = ? AND stud_first_name = ? AND stud_last_name = ? AND stud_middle_name = ? AND
stud_fathername = ? AND stud_mothername = ? AND stud_ext_name = ? AND semester_enrolled = ? and  school_year_enrolled = ?";
if($stmt11 = mysqli_prepare($link, $checkifstudentalreadyexistsquery)){
			mysqli_stmt_bind_param($stmt11, "issssssss", $param_stud_lrn, $param_stud_first_name, $param_stud_last_name, $param_stud_middle_name, $param_stud_fathername, $param_stud_mothername, $param_stud_ext_name,  $param_semester_enrolled, $param_school_year_enrolled);

			$param_stud_lrn= $studLRN;
			$param_stud_first_name= $studFname;
			$param_stud_last_name= $studLname;
			$param_stud_middle_name= $studMname;
			$param_stud_fathername= $studFathersName;
			$param_stud_mothername= $studMothersName;
			$param_stud_ext_name= $studExtname;
			$param_semester_enrolled= $studSem;
			$param_school_year_enrolled= $studSY;
			if(mysqli_stmt_execute($stmt11)){
					$result = mysqli_stmt_get_result($stmt11);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$count = $row["COUNT(student_id)"];
						
				}

				if ( $count == 0 ) {
$createJuniorHighQuery = "INSERT INTO jr_high_info (jrhigh_name, jrhigh_address, jrhigh_completion) VALUES (?, ?, ?)";
		 if($stmt = mysqli_prepare($link, $createJuniorHighQuery)){
			mysqli_stmt_bind_param($stmt, "sss", $param_jrhigh_name, $param_jrhigh_address, $param_jrhigh_completion);
			$param_jrhigh_name = $jrhighName;
			$param_jrhigh_address = $jrhighAddress;
			$param_jrhigh_completion = $jrhighCompletion;
			if(mysqli_stmt_execute($stmt)){

				mysqli_stmt_close($stmt);
			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}

$createStudAddressQuery = "INSERT INTO stud_address (house_number_street, subdivision_baranggay, city_municipality, province, country, postal_code) VALUES (?, ?, ?, ?, ?, ?)";
 if($stmt = mysqli_prepare($link, $createStudAddressQuery)){
			mysqli_stmt_bind_param($stmt, "sssssi", $param_house_number_street, $param_subdivision_baranggay, $param_city_municipality, $param_province, $param_country, $param_postal_code);
			$param_house_number_street = $studHouseNoandStreet;
			$param_subdivision_baranggay = $studSubdBrgy;
			$param_city_municipality = $studCityMun;
			$param_province = $studProvince;
			$param_country = $studCountry;
			$param_postal_code = $studPostal;
			if(mysqli_stmt_execute($stmt)){

				$stud_number= mysqli_insert_id($link);

				mysqli_stmt_close($stmt);
			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}
$stud_address_number = $stud_number;
$stud_jrhigh_number = $stud_number;

$createStudInfoQuery= "INSERT INTO student_info (stud_lrn, stud_first_name, stud_last_name, stud_middle_name, stud_email, stud_mobile, stud_telephone, stud_address_number, stud_fathername, stud_mothername, stud_ext_name, stud_guardian, stud_age, stud_sex, indigenouspeople_or_cultural, stud_religion, stud_birthdate, stud_bloodtype, stud_jrhigh_number, stud_status, section_id, stud_gradelevel, specialization_id, voucher_recipient, stud_date_enrolled, semester_enrolled, school_year_enrolled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
if($stmt = mysqli_prepare($link, $createStudInfoQuery)){
			mysqli_stmt_bind_param($stmt, "issssssissssisssssisiiiisis", $param_stud_lrn, $param_stud_first_name, $param_stud_last_name, $param_stud_middle_name, $param_stud_email, $param_stud_mobile, $param_stud_telephone, $param_stud_address_number, $param_stud_fathername, $param_stud_mothername, $param_stud_ext_name, $param_stud_guardian, $param_stud_age, $param_stud_sex, $param_indigenouspeople_or_cultural, $param_stud_religion, $param_stud_birthdate, $param_stud_bloodtype, $param_stud_jrhigh_number, $param_stud_status, $param_section_id, $param_stud_gradelevel, $param_specialization_id,$param_voucher_recipient, $param_stud_date_enrolled, $param_semester_enrolled, $param_school_year_enrolled);

			$param_stud_lrn= $studLRN;
			$param_stud_first_name= $studFname;
			$param_stud_last_name= $studLname;
			$param_stud_middle_name= $studMname;
			$param_stud_email= $studEmail;
			$param_stud_mobile= $studCellphone;
			$param_stud_telephone= $studTelephone;
			$param_stud_address_number= $stud_address_number;
			$param_stud_fathername= $studFathersName;
			$param_stud_mothername= $studMothersName;
			$param_stud_ext_name= $studExtname;
			$param_stud_guardian= $studGuardiansName;
			$param_stud_age= $studAge;
			$param_stud_sex= $studSex;
			$param_indigenouspeople_or_cultural= $studIP;
			$param_stud_religion= $studReligion;
			$param_stud_birthdate= $studBdate;
			$param_stud_bloodtype= $studBloodType;
			$param_stud_jrhigh_number= $stud_jrhigh_number;
			$param_stud_status= $studStatus;
			$param_section_id= $studSection;
			$param_stud_gradelevel= $studGradeLevel;
			$param_specialization_id= $studSpecialization;
			$param_voucher_recipient= $studVoucher;
			$param_stud_date_enrolled= $studEnrollDate;
			$param_semester_enrolled= $studSem;
			$param_school_year_enrolled= $studSY;
			if(mysqli_stmt_execute($stmt)){


				mysqli_stmt_close($stmt);
			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}

$getSubjectLoadsForSectionQuery = "SELECT class_id FROM class_assignment LEFT JOIN instructor_info ON (class_assignment.instructor_id = instructor_info.instructor_id) WHERE section_id = ? AND semester_offered = ?";
 if($stmt = mysqli_prepare($link, $getSubjectLoadsForSectionQuery)){
			mysqli_stmt_bind_param($stmt, "ii", $param_studSection, $param_studSem);
			$param_studSection = $studSection;
			$param_studSem = $studSem;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){


						$insertIntoClassListQuery = "INSERT INTO class_list (student_id, class_id) VALUES (?,?)";
						 if($stmt2 = mysqli_prepare($link, $insertIntoClassListQuery)){
						mysqli_stmt_bind_param($stmt2, "ii", $param_student_id, $param_class_id);
						$param_student_id = $stud_number;
						$param_class_id = $row["class_id"];
						if(mysqli_stmt_execute($stmt2)){

							mysqli_stmt_close($stmt2);
						}
						 else{
								die(mysqli_error($link));
							}
							}
						else{
							die(mysqli_error($link));

						}

					}

				mysqli_stmt_close($stmt);

				echo "subjectloads.php?studentNumber=".$stud_number."&school_year_enrolled=".$studSY."&sem_enrolled=".$studSem;

			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}	
/////////////////////////////
$decrementSectionAvailabilityQuery = "UPDATE section_info SET max_population = max_population - 1 where section_id =?";
 if($stmt = mysqli_prepare($link, $decrementSectionAvailabilityQuery)){
			mysqli_stmt_bind_param($stmt, "i", $param_studSection);
			$param_studSection = $studSection;
			if(mysqli_stmt_execute($stmt)){
			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}	


		}
		else{
			echo "Student already registered!";
		}


				mysqli_stmt_close($stmt11);
			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}


?>

