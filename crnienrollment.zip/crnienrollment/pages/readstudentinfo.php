<?php
include "../includes/crnheader.php";
?>
<?php
$student_id = $_GET["student_id"];
$schoolYear = $_GET["schoolYear"];
$semester = $_GET["semester"];
$queryforgettingstudentinfoFULL = "SELECT * FROM section_info LEFT JOIN (stud_address RIGHT JOIN (student_info LEFT JOIN (specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id=track_info.track_id ) ON specialization_info.strand_id=strand_info.strand_id) ON student_info.specialization_id = specialization_info.specialization_id) ON   stud_address.stud_address_number =student_info.stud_address_number) ON section_info.section_id = student_info.section_id WHERE student_id = ? AND school_year_enrolled = ? AND semester_enrolled = ? ";
 if($stmt1 = mysqli_prepare($link, $queryforgettingstudentinfoFULL)){
			mysqli_stmt_bind_param($stmt1, "isi", $param_studentID1, $param_school_year_enrolled1, $param_sem_enrolled1);
			$param_studentID1 = $student_id;
			$param_school_year_enrolled1 = $schoolYear;
			$param_sem_enrolled1 = $semester;
			if(mysqli_stmt_execute($stmt1)){
				$result = mysqli_stmt_get_result($stmt1);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$studentLRN= $row["stud_lrn"];
						$studentName=$row["stud_first_name"]." ".$row["stud_middle_name"]." ".$row["stud_last_name"]." ".$row["stud_ext_name"];
						$studentFName=$row["stud_first_name"];
						$studentMName=$row["stud_middle_name"];
						$studentLName=$row["stud_last_name"];
						$studentEName=$row["stud_ext_name"];
						$age = $row["stud_age"];
						$sex= $row["stud_sex"];
						$bloodtype= $row["stud_bloodtype"];
						$bday= $row["stud_birthdate"];
						$status = $row["stud_status"];
						$studIP = $row["indigenouspeople_or_cultural"];
						$religion = $row["stud_religion"];
						$address = $row["house_number_street"]." ".$row["subdivision_baranggay"]." ".$row["city_municipality"]." ".$row["province"]." ".$row["country"]." ".$row["postal_code"];
						$house = $row["house_number_street"];
						$subd = $row["subdivision_baranggay"];
						$city_mun = $row["city_municipality"];
						$province = $row["province"];
						$country = $row["country"];
						$postal = $row["postal_code"];

						$studmobile = $row["stud_mobile"];
						$telephone = $row["stud_telephone"];
						$email = $row["stud_email"];
						$mother = $row["stud_mothername"];
						$fathername = $row["stud_fathername"];
						$guardian = $row["stud_guardian"];
						
						$gradelvl= $row["stud_gradelevel"];
						$section= $row["section_name"];
						$specialization = $row["specialization_title"];
						$strand =  $row["strand_title"];
						$track =  $row["track_title"];
						$SY= $row["school_year_enrolled"];
						$sem= $row["semester_enrolled"];
						$voucher = $row["voucher_recipient"];
						

				}

				mysqli_stmt_close($stmt1);


			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}
?>
<div>
<center>
<div></div>

<div id="toHide" style="display: block;">
	<div style="margin-left: 20px; margin-right: 20px; margin-bottom: 30px;">
	<table >
	<tr>
	<td id="noborder" >
		<label>NAME:</label>
		<b><?php echo $studentName; ?></b><br/>
		<label>STUDENT LRN:</label>
		<?php echo $studentLRN; ?><br>
		</td>
		<td>
		<button class="btn btn-success" onclick="displayForm();" style="width: 100%;">UPDATE Profile</button>

		</td>
		</tr>
		<tr>
		<td>
		<label>SECTION:</label>
		<?php echo $section; ?>
		<label>GRADE LEVEL:</label>
		<?php echo $gradelvl; ?><br/>
		<label>SPECIALIZATION:</label>
		<?php echo $specialization; ?><br/>
		<label>TRACK:</label>
		<?php echo $track; ?><BR/>
		<label>STRAND:</label>
		<?php echo $strand; ?><br/> 
		<label>VOUCHER RECIPIENT:</label>
		<?php 
		if ($voucher== 1) {
			echo "YES";
		}
		else{
			echo "NO";
		}

		?><br/>
		<label>SY and SEMESTER:</label>
		<?php echo $SY." Semester number ".$sem; ?>	<br/><br/>
		<label>MOBILE PHONE NUMBER:</label>
		<?php echo $studmobile; ?><br/>
		<label>TELEPHONE:</label>
		<?php echo	$telephone;?><br/>
		<label>EMAIL ADDRESS:</label>
		<?php echo	$email;?><br/>

		<label>ADDRESS:</label>
		<?php echo $address; ?><br/>

	
		</td>
		<td>
		<label>AGE:</label>
		<?php echo $age; ?>
		<label>BIRTHDATE:</label>
		<?php echo $bday; ?><br/>
		<label>SEX:</label>
		<?php echo	$sex;?><br/>
		<label>BLOOD TYPE:</label>
		<?php echo	$bloodtype;?><br/>
		<label>MARITAL STATUS:</label>
		<?php echo	$status;?><br/>
		<label>MEMBER OF INDIGENOUS PEOPLE'S COMMUNITY:</label>
		<?php echo $studIP; ?>
		<label>RELIGION:</label>
		<?php echo	$religion;?><br/>

		<label>FATHER'S NAME:</label>
		<?php echo	$fathername;?><br/>
		<label>MOTHER'S NAME:</label>
		<?php echo	$mother;?><br/>
		<label>GUARDIAN NAME:</label>
		<?php echo	$guardian;?><br/>

		</td>
	</tr>
	</table>
	</div>
	
	<h2>Officially Enrolled</h2>

	<table id="student" style="width: 80%; border-color: black;" >
	<tr>
	<th>SUBJECT CODE</th>
	<th>SUBJECT TITLE</th>
	<th>CLASSROOM</th>
	<th>INSTRUCTOR</th>
	<th>UNITS</th>
	</tr>

	<?php
$queryforgettingsubjectload = "SELECT * FROM student_info LEFT JOIN (class_list LEFT JOIN (instructor_info RIGHT JOIN (class_assignment LEFT JOIN subject_info on class_assignment.subject_code = subject_info.subject_code) ON instructor_info.instructor_id = class_assignment.instructor_id) ON class_list.class_id = class_assignment.class_id) ON student_info.student_id = class_list.student_id WHERE student_info.student_id= ? AND school_year_enrolled = ? AND semester_enrolled = ?";
 if($stmt = mysqli_prepare($link, $queryforgettingsubjectload)){
			mysqli_stmt_bind_param($stmt, "isi", $param_studentID, $param_school_year_enrolled, $param_sem_enrolled);
			$param_studentID = $student_id;
			$param_school_year_enrolled = $schoolYear;
			$param_sem_enrolled = $semester;
			if(mysqli_stmt_execute($stmt)){
				$result = mysqli_stmt_get_result($stmt);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){

						echo "<tr>";
						echo "<td id='noborder'>".$row['subject_code']."</td>";
						echo "<td id='noborder'>".$row['subject_description']."</td>";
						echo "<td id='noborder'>".$row['classroom_no']."</td>";
						echo "<td id='noborder'>".$row['inst_fname']." ".$row['inst_mname']." ".$row['inst_lname']."</td>";
						echo "<td id='noborder'>".$row['subject_units']."</td>";
						echo "</tr>";
					}

				mysqli_stmt_close($stmt);


			}
		 else{
				die(mysqli_error($link));
			}
		}
		else{
			die(mysqli_error($link));

		}	?>
			</table>
		</div>
		<div id="notToPrint">
		<button onclick="printPage();">PRINT</button>
	</div>
<script type="text/javascript">
	function printPage(){
		document.getElementById("notToPrint").style.display="none";
		window.print();
		document.getElementById("notToPrint").style.display="block";
	}</script>
			</center>

<div id="updateStudForm" style="display: none;">
<form name="updateStudForm" method="post" onsubmit="return validateUpdateForm(); " >
	<label>I. STUDENT INFORMATION</label><br/>
	<label>1. LEARNER REFERENCE NUMBER (LRN): </label>
	<input type="text" name="studid" value="<?php echo $student_id; ?>" maxlength="30" hidden><br/>
	<input type="number" name="studLRN" value="<?php echo $studentLRN; ?>" maxlength="12"><br/>
	<span id="LRNError"></span><br/>	
	<label>2. NAME OF STUDENT*</label><br/>
		<label>LAST*</label>
		<input type="text" name="studLname" value="<?php echo $studentLName; ?>" maxlength="30" required><br/>
		<span id="LnameError"></span><br/>
		<label>FIRST*</label>
		<input type="text" name="studFname" value="<?php echo $studentFName; ?>" maxlength="30" value="<?php echo $row["stud_first_name"];?>" required><br/>
		<span id="FnameError"></span><br/>
		<label>MIDDLE (If any. Place "Not Applicable" if none)</label>
		<input type="text" name="studMname" value="<?php echo $studentMName; ?>" maxlength="30" required ><br/>
		<span id="MnameError"></span><br/>
		<label>EXTENSION NAME (If any)</label>
		<input type="text" name="studExtname" value="<?php echo $studentEName; ?>" maxlength="5" ><br/>
		<span id="ExtnameError"></span><br/>
	<label>3. AGE*</label>
		<input type="number" name="studAge" value="<?php echo $age; ?>" maxlength="3" required><br/>
		<span id="AgeError"></span><br/>
	<label>4.1. SEX*</label>
		<input type="radio" name="studSex" value="MALE" <?php if ($sex=='MALE') { echo "checked='checked'";}?> required> Male
		<input type="radio" name="studSex" value="FEMALE" <?php if ($sex=='FEMALE') { echo "checked='checked'";}?> > Female<br/>
	<label>4.1. BLOOD TYPE*</label>
		<select name="studBloodType">
			<option value=""></option>
			<option value="A+" <?php if ($bloodtype =='A+')  echo "selected";?> >A+</option>
			<option value="A-" <?php if ($bloodtype =='A-')  echo "selected";?> >A-</option>
			<option value="B+" <?php if ($bloodtype =='B+')  echo "selected";?> >B+</option>
			<option value="B-" <?php if ($bloodtype =='B-')  echo "selected";?> >B-</option>
			<option value="AB+" <?php if ($bloodtype =='AB+')  echo "selected";?> >AB+</option>
			<option value="AB-" <?php if ($bloodtype =='AB-')  echo "selected";?> >AB-</option>
			<option value="O+" <?php if ($bloodtype =='O+')  echo "selected";?> >O+</option>
			<option value="O-" <?php if ($bloodtype =='O-')  echo "selected";?> >O-</option>
		</select>
	<label>5. Marital Status*</label><br/>
	<select name="studStatus">
		<option value=""></option>
		<option value="Single" <?php if ($status=='Single')  echo "selected";?> >Single</option>
		<option value="Married" <?php if ($status=='Married')  echo "selected";?> >Married</option>
		<option value="Divorced" <?php if ($status=='Divorced')  echo "selected";?> >Divorced</option>
		<option value="Separated" <?php if ($status=='Separated')  echo "selected";?> >Separated</option>
		<option value="Widowed"  <?php if ($status=='Widowed')  echo "selected";?>>Widowed</option>	
	</select>

	<label>6.1 BELONGS TO INDIGENOUS PEOPLES (IP)/ INDIGENOUS CULTURAL (IC) COMMUNITY?*</label><br/>
		<input type="radio" name="studIP" value="1" <?php if ($sex='MALE') { echo "checked='checked'";}?> > YES
		<input type="radio" name="studIP" value="0" <?php if ($sex='MALE') { echo "checked='checked'";}?> required> NO<br/>
	<label>6.2 RELIGION (Type a Religion in the textbox if not in the choices)*</label>
		<select name="studReligion" onchange="otherreligionsupdate(this.value);" required>
			<option value=""></option>
			<option value="Iglesia ni Cristo" <?php if ($religion=='Iglesia ni Cristo')  echo "selected";?> >Iglesia ni Cristo</option>
			<option value="Islam" <?php if ($religion=='Islam')  echo "selected";?> >Islam</option>
			<option value="Protestant Christianity" <?php if ($religion=='Protestant Christianity')  echo "selected";?> >Protestant Christianity</option>
			<option value="Roman Catholic Christianity" <?php if ($religion=='Roman Catholic Christianity')  echo "selected";?> >Roman Catholic Christianity</option>
			<option value="others" <?php if (($religion != "Iglesia ni Cristo") && ($religion != "Islam") && ($religion != "Protestant Christianity") && ($religion != "Roman Catholic Christianity")){ 
							echo "selected";
							}?> >Others</option>
		</select><br/>
		<label>Type a Religion if not in the choices</label>
		<input type="text" name="studOtherReligion" id="studOtherReligion" value="<?php if ($religion !='Iglesia ni Cristo' && $religion != 'Islam' && $religion != 'Protestant Christianity' && $religion != 'Roman Catholic Christianity')  echo $religion;?> "   maxlength="30"><br/>
		<span id="ReligionError"></span><br/>
	<label>7. PERMANENT HOME ADDRESS*</label><br/>
		<label>House Number and Street</label>
		<input type="text" name="studHouseNoandStreet" value="<?php echo $house; ?>" maxlength="50" required><br/>
		<span id="HouseNoandStreetError"></span><br/>
		<label>Subdivision/Baranggay</label>
		<input type="text" name="studSubdBrgy" value="<?php echo $subd; ?>" maxlength="50" required><br/>
		<span id="SubdBrgyError"></span><br/>
		<label>City/Municipality</label>
		<input type="text" name="studCityMun" value="<?php echo $city_mun; ?>" maxlength="50" required><br/>
		<span id="CityMunError"></span><br/>
		<label>Province</label>
		<input type="text" name="studProvince" value="<?php echo $province; ?>" maxlength="50" required><br/>
		<span id="ProvinceError"></span><br/>
		<label>Country</label>
		<input type="text" name="studCountry" value="<?php echo $country; ?>" maxlength="50" required><br/>
		<span id="CountryError"></span><br/>
		<label>Postal/Zip Code</label>
		<input type="number" name="studPostal" value="<?php echo $postal; ?>" maxlength="10" required><br/>
		<span id="PostalError"></span><br/>
	<label>8. PARENT/S OR GUARDIAN'S NAME*</label><br/>
		<label>Mother's Name: </label>
		<input type="text" name="studMothersName" value="<?php echo $mother; ?>" maxlength="90" required><br/>
		<span id="MothersNameError"></span><br/>
		<label>Father's Name: </label>
		<input type="text" name="studFathersName" value="<?php echo $fathername; ?>" maxlength="90" required><br/>
		<span id="FathersNameError"></span><br/>
		<label>Guardian's Name: </label>
		<input type="text" name="studGuardiansName" value="<?php echo $guardian; ?>" maxlength="90" required><br/>
		<span id="GuardiansNameError"></span><br/>
	<label>9. CONTACT INFORMATION*</label><br/>
		<label>Telephone Number</label>
		<input type="text" name="studTelephone" value="<?php echo $telephone; ?>" maxlength="13"><br/>
		<label>Cellphone Number</label>
		<input type="text" name="studCellphone" value="<?php echo $studmobile; ?>" minlength ="11" maxlength="11" required><br/>
		<span id="CellphoneError"></span><br/>
		<label>E-mail Address</label>
		<input type="text" name="studEmail" value="<?php echo $email; ?>" maxlength="30" required><br/>
		<span id="EmailError"></span><br/>
<input class="btn btn-success"  type="SUBMIT"  value="SUBMIT">
</form><br/>
<button class="btn btn-warning" onclick="hideupdateform();">CANCEL</button>
</div>
</div>
<?php
include "../includes/crnfooter.php";
?>
