<?php
include "../includes/dbconfig.php";
?>

<?php
$studentToSearch= $_GET["studentToSearch"];
$schoolYear= $_GET["schoolYear"];
$semester=$_GET["semester"];	
$criteria = $_GET["criteria"]; 
if (isset($_GET['pageno'])) {
    $pageno = $_GET['pageno'];
} else {
    $pageno = 1;
}
$no_of_records_per_page = 20;
$offset = ($pageno-1) * $no_of_records_per_page; ;
					echo "<thead>";
						echo "<tr><th>";
				            echo       "Learner Reference Number";
				            echo    "</th>";
				            echo    "<th>";
				            echo       "Last Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo       "First Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Middle Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Extension Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Age";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Sex";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Date of Birth";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Indigenous Belonging";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "House No. and Street";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Subdivision/Baranggay";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "City/Municipality";
				            echo   " </th>";
				            echo    "<th>";
				            echo       "Province";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Country";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Postal Code";
				            echo    "</th>";
				            echo   "<th>";
				            echo        "Mother's Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Father's Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Guardian's Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Cellphone Number";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Telephone Number";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Email Address";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "JHS Name";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "JHS Address";
				            echo    "</th>";
				            echo    "<th>";
				            echo        "Specialization";
				            echo    "</th>";
				            echo    "<th>Actions</th>";
				        echo    "</tr>";
				     echo    "</thead>";

if (!empty($criteria) && $criteria != "stud_age"  && $criteria != "postal_code" && $criteria != "stud_sex") {
$queryforgettingstudentinfo = "SELECT * FROM jr_high_info  LEFT JOIN (section_info LEFT JOIN (stud_address RIGHT JOIN (student_info LEFT JOIN (specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id=track_info.track_id ) ON specialization_info.strand_id=strand_info.strand_id) ON student_info.specialization_id = specialization_info.specialization_id) ON   stud_address.stud_address_number =student_info.stud_address_number) ON section_info.section_id = student_info.section_id) on jr_high_info.stud_jrhigh_number = student_info.stud_jrhigh_number WHERE ".$criteria." REGEXP ? AND school_year_enrolled = ? AND semester_enrolled = ? ORDER BY student_info.student_id";
 if($stmt1 = mysqli_prepare($link, $queryforgettingstudentinfo)){
			mysqli_stmt_bind_param($stmt1, "ssi", $param_tosearch, $param_school_year_enrolled1, $param_sem_enrolled1);
			$param_tosearch = $studentToSearch;
			$param_school_year_enrolled1 = $schoolYear;
			$param_sem_enrolled1 = $semester;
			if(mysqli_stmt_execute($stmt1)){
				$result = mysqli_stmt_get_result($stmt1);
				$rownumbers = mysqli_num_rows($result);
				$total_pages = ceil($rownumbers / $no_of_records_per_page);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$student_id = $row["student_id"];
						$studentresult = $row[$criteria];
						$studentLRN= $row["stud_lrn"];
						$studentName=$row["stud_first_name"]." ".$row["stud_middle_name"]." ".$row["stud_last_name"]." ".$row["stud_ext_name"];
						$studentFName=$row["stud_first_name"];
						$studentMName=$row["stud_middle_name"];
						$studentLName=$row["stud_last_name"];
						$studentEName=$row["stud_ext_name"];
						$age = $row["stud_age"];
						$sex= $row["stud_sex"];
						$bloodtype= $row["stud_bloodtype"];
						$bday= $row["stud_birthdate"];
						$status = $row["stud_status"];
						$studIP = $row["indigenouspeople_or_cultural"];
						$religion = $row["stud_religion"];
						$address = $row["house_number_street"]." ".$row["subdivision_baranggay"]." ".$row["city_municipality"]." ".$row["province"]." ".$row["country"]." ".$row["postal_code"];
						$house = $row["house_number_street"];
						$subd = $row["subdivision_baranggay"];
						$city_mun = $row["city_municipality"];
						$province = $row["province"];
						$country = $row["country"];
						$postal = $row["postal_code"];

						$studmobile = $row["stud_mobile"];
						$telephone = $row["stud_telephone"];
						$email = $row["stud_email"];
						$mother = $row["stud_mothername"];
						$fathername = $row["stud_fathername"];
						$guardian = $row["stud_guardian"];
						
						$gradelvl= $row["stud_gradelevel"];
						$section= $row["section_name"];
						$specialization = $row["specialization_title"];
						$strand =  $row["strand_title"];
						$track =  $row["track_title"];
						$SY= $row["school_year_enrolled"];
						$sem= $row["semester_enrolled"];
						$voucher = $row["voucher_recipient"];
						$jrhigh_name = $row["jrhigh_name"];
						$jrhigh_address = $row["jrhigh_address"];

						if (!empty($studentToSearch)) {

						if ((stripos($studentresult, $studentToSearch) !== false)) {
				            echo    "<tbody>";
							echo "<tr><th>";
				            echo       $studentLRN;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentLName;
				            echo    "</td>";
				            echo    "<td>";
				            echo       $studentFName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentMName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentEName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $age;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $sex;
				            echo    "</td>";
				            echo    "<td>";
				            		$bdate = date_create($bday);
				            echo    date_format($bdate,"M. d, Y");
				            echo    "</th>";
				            echo    "<td>";
				            echo        $studIP;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $house;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $subd;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $city_mun;
				            echo   " </td>";
				            echo    "<td>";
				            echo        $province;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $country;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $postal;
				            echo    "</th>";
				            echo   "<td>";
				            echo        $mother;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $fathername;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $guardian;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studmobile;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $telephone;
				            echo    "</td>";
				            echo    "<td> <a href='mailto: ".$email."'>";
				            echo        $email;
				            echo    "</a></td>";
				            echo    "<td>";
				            echo        $jrhigh_name;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $jrhigh_address;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $specialization;
				            echo    "</td>";
				            echo    "<td><button class='btn btn-success' style='width: 100%;'><a href='readstudentinfo.php?studentName=".$studentName."&student_id=".$student_id."&student_id=".$student_id."&schoolYear=".$schoolYear."&semester=".$semester."' target='_blank'  style='color: rgb(255,255,255)' > READ and UPDATE Profile </a></button></td>";
				        echo    "</tr>";					
				            echo    "</tbody>";
						}

						}
						
				}

				mysqli_stmt_close($stmt1);


			}
		 else{
				 echo mysqli_error($link);
			}
		}
		else{
				 echo mysqli_error($link);

		}

}
else if (!empty($criteria)  && $criteria == "stud_sex" && $criteria != "stud_age"  && $criteria != "postal_code") {
$queryforgettingstudentinfo = "SELECT * FROM jr_high_info  LEFT JOIN (section_info LEFT JOIN (stud_address RIGHT JOIN (student_info LEFT JOIN (specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id=track_info.track_id ) ON specialization_info.strand_id=strand_info.strand_id) ON student_info.specialization_id = specialization_info.specialization_id) ON   stud_address.stud_address_number =student_info.stud_address_number) ON section_info.section_id = student_info.section_id) on jr_high_info.stud_jrhigh_number = student_info.stud_jrhigh_number WHERE ".$criteria." = ? AND school_year_enrolled = ? AND semester_enrolled = ? ORDER BY student_info.student_id";
 if($stmt1 = mysqli_prepare($link, $queryforgettingstudentinfo)){
			mysqli_stmt_bind_param($stmt1, "ssi", $param_tosearch, $param_school_year_enrolled1, $param_sem_enrolled1);
			$param_tosearch = $studentToSearch;
			$param_school_year_enrolled1 = $schoolYear;
			$param_sem_enrolled1 = $semester;
			if(mysqli_stmt_execute($stmt1)){
				$result = mysqli_stmt_get_result($stmt1);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$student_id = $row["student_id"];
						$studentresult = $row[$criteria];
						$studentLRN= $row["stud_lrn"];
						$studentName=$row["stud_first_name"]." ".$row["stud_middle_name"]." ".$row["stud_last_name"]." ".$row["stud_ext_name"];
						$studentFName=$row["stud_first_name"];
						$studentMName=$row["stud_middle_name"];
						$studentLName=$row["stud_last_name"];
						$studentEName=$row["stud_ext_name"];
						$age = $row["stud_age"];
						$sex= $row["stud_sex"];
						$bloodtype= $row["stud_bloodtype"];
						$bday= $row["stud_birthdate"];
						$status = $row["stud_status"];
						$studIP = $row["indigenouspeople_or_cultural"];
						$religion = $row["stud_religion"];
						$address = $row["house_number_street"]." ".$row["subdivision_baranggay"]." ".$row["city_municipality"]." ".$row["province"]." ".$row["country"]." ".$row["postal_code"];
						$house = $row["house_number_street"];
						$subd = $row["subdivision_baranggay"];
						$city_mun = $row["city_municipality"];
						$province = $row["province"];
						$country = $row["country"];
						$postal = $row["postal_code"];

						$studmobile = $row["stud_mobile"];
						$telephone = $row["stud_telephone"];
						$email = $row["stud_email"];
						$mother = $row["stud_mothername"];
						$fathername = $row["stud_fathername"];
						$guardian = $row["stud_guardian"];
						
						$gradelvl= $row["stud_gradelevel"];
						$section= $row["section_name"];
						$specialization = $row["specialization_title"];
						$strand =  $row["strand_title"];
						$track =  $row["track_title"];
						$SY= $row["school_year_enrolled"];
						$sem= $row["semester_enrolled"];
						$voucher = $row["voucher_recipient"];
						$jrhigh_name = $row["jrhigh_name"];
						$jrhigh_address = $row["jrhigh_address"];

						if (!empty($studentToSearch)) {

						if ((stripos($studentresult, $studentToSearch) !== false)) {
				            echo    "<tbody>";
							echo "<tr><th>";
				            echo       $studentLRN;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentLName;
				            echo    "</td>";
				            echo    "<td>";
				            echo       $studentFName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentMName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentEName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $age;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $sex;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $bday;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $studIP;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $house;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $subd;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $city_mun;
				            echo   " </td>";
				            echo    "<td>";
				            echo        $province;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $country;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $postal;
				            echo    "</th>";
				            echo   "<td>";
				            echo        $mother;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $fathername;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $guardian;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studmobile;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $telephone;
				            echo    "</td>";
				            echo    "<td> <a href='mailto: ".$email."'>";
				            echo        $email;
				            echo    "</a></td>";
				            echo    "<td>";
				            echo        $jrhigh_name;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $jrhigh_address;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $specialization;
				            echo    "</td>";
				            echo    "<td><button class='btn btn-success' style='width: 100%;'><a href='readstudentinfo.php?studentName=".$studentName."&student_id=".$student_id."&student_id=".$student_id."&schoolYear=".$schoolYear."&semester=".$semester."' target='_blank'  style='color: rgb(255,255,255)' > READ and UPDATE Profile </a></button></td>";
				        echo    "</tr>";					
				            echo    "</tbody>";
						}

						}
						
				}

				mysqli_stmt_close($stmt1);


			}
		 else{
				 echo mysqli_error($link);
			}
		}
		else{
				 echo mysqli_error($link);

		}

}
else if (!empty($criteria) && ($criteria == "stud_age" || $criteria == "postal_code") && $criteria != "stud_sex") {
$queryforgettingstudentinfo = "SELECT * FROM jr_high_info  LEFT JOIN (section_info LEFT JOIN (stud_address RIGHT JOIN (student_info LEFT JOIN (specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id=track_info.track_id ) ON specialization_info.strand_id=strand_info.strand_id) ON student_info.specialization_id = specialization_info.specialization_id) ON   stud_address.stud_address_number =student_info.stud_address_number) ON section_info.section_id = student_info.section_id) on jr_high_info.stud_jrhigh_number = student_info.stud_jrhigh_number WHERE ".$criteria." REGEXP ? AND school_year_enrolled = ? AND semester_enrolled = ? ORDER BY student_info.student_id";
 if($stmt1 = mysqli_prepare($link, $queryforgettingstudentinfo)){
			mysqli_stmt_bind_param($stmt1, "isi", $param_tosearch, $param_school_year_enrolled1, $param_sem_enrolled1);
			$param_tosearch = $studentToSearch;
			$param_school_year_enrolled1 = $schoolYear;
			$param_sem_enrolled1 = $semester;
			if(mysqli_stmt_execute($stmt1)){
				$result = mysqli_stmt_get_result($stmt1);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						$student_id = $row["student_id"];
						$studentresult = $row[$criteria];
						$studentLRN= $row["stud_lrn"];
						$studentName=$row["stud_first_name"]." ".$row["stud_middle_name"]." ".$row["stud_last_name"]." ".$row["stud_ext_name"];
						$studentFName=$row["stud_first_name"];
						$studentMName=$row["stud_middle_name"];
						$studentLName=$row["stud_last_name"];
						$studentEName=$row["stud_ext_name"];
						$age = $row["stud_age"];
						$sex= $row["stud_sex"];
						$bloodtype= $row["stud_bloodtype"];
						$bday= $row["stud_birthdate"];
						$status = $row["stud_status"];
						$studIP = $row["indigenouspeople_or_cultural"];
						$religion = $row["stud_religion"];
						$address = $row["house_number_street"]." ".$row["subdivision_baranggay"]." ".$row["city_municipality"]." ".$row["province"]." ".$row["country"]." ".$row["postal_code"];
						$house = $row["house_number_street"];
						$subd = $row["subdivision_baranggay"];
						$city_mun = $row["city_municipality"];
						$province = $row["province"];
						$country = $row["country"];
						$postal = $row["postal_code"];

						$studmobile = $row["stud_mobile"];
						$telephone = $row["stud_telephone"];
						$email = $row["stud_email"];
						$mother = $row["stud_mothername"];
						$fathername = $row["stud_fathername"];
						$guardian = $row["stud_guardian"];
						
						$gradelvl= $row["stud_gradelevel"];
						$section= $row["section_name"];
						$specialization = $row["specialization_title"];
						$strand =  $row["strand_title"];
						$track =  $row["track_title"];
						$SY= $row["school_year_enrolled"];
						$sem= $row["semester_enrolled"];
						$voucher = $row["voucher_recipient"];
						$jrhigh_name = $row["jrhigh_name"];
						$jrhigh_address = $row["jrhigh_address"];

						if (!empty($studentToSearch)) {

						if ((stripos($studentresult, $studentToSearch) !== false)) {
				            echo    "<tbody>";
							echo "<tr><th>";
				            echo       $studentLRN;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentLName;
				            echo    "</td>";
				            echo    "<td>";
				            echo       $studentFName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentMName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studentEName;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $age;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $sex;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $bday;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $studIP;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $house;
				            echo    "</th>";
				            echo    "<td>";
				            echo        $subd;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $city_mun;
				            echo   " </td>";
				            echo    "<td>";
				            echo        $province;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $country;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $postal;
				            echo    "</th>";
				            echo   "<td>";
				            echo        $mother;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $fathername;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $guardian;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $studmobile;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $telephone;
				            echo    "</td>";
				            echo    "<td> <a href='mailto: ".$email."'>";
				            echo        $email;
				            echo    "</a></td>";
				            echo    "<td>";
				            echo        $jrhigh_name;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $jrhigh_address;
				            echo    "</td>";
				            echo    "<td>";
				            echo        $specialization;
				            echo    "</td>";
				            echo    "<td><button class='btn btn-success' style='width: 100%;'><a href='readstudentinfo.php?studentName=".$studentName."&student_id=".$student_id."&student_id=".$student_id."&schoolYear=".$schoolYear."&semester=".$semester."' target='_blank'  style='color: rgb(255,255,255)' > READ and UPDATE Profile </a></button></td>";
				        echo    "</tr>";					
				            echo    "</tbody>";
						}

						}
						
				}

				mysqli_stmt_close($stmt1);


			}
		 else{
				 echo mysqli_error($link);
			}
		}
		else{
				 echo mysqli_error($link);

		}

}
?>