<html>
	<head>
		<title>My First MVC</title>
		<style type="text/css">
			a.navbar-brand {
			  white-space: normal;
			  text-align: center;
			  word-break: break-all;
			}

			/* Sticky footer styles
			-------------------------------------------------- */
			html {
			  font-size: 14px;
			}
			@media (min-width: 768px) {
			  html {
			    font-size: 16px;
			  }
			}

			.border-top {
			  border-top: 1px solid #e5e5e5;
			}
			.border-bottom {
			  border-bottom: 1px solid #e5e5e5;
			}

			.box-shadow {
			  box-shadow: 0 .25rem .75rem rgba(0, 0, 0, .05);
			}

			button.accept-policy {
			  font-size: 1rem;
			  line-height: inherit;
			}

			/* Sticky footer styles
			-------------------------------------------------- */
			html {
			  position: relative;
			  min-height: 100%;
			}

			body {
			  /* Margin bottom by footer height */
			  margin-bottom: 60px;
			}
			.footer {
			  position: absolute;
			  bottom: 0;
			  width: 100%;
			  white-space: nowrap;
			  /* Set the fixed height of the footer here */
			  height: 60px;
			  line-height: 60px; /* Vertically center the text there */
			}
		</style>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
	</head>
	<body>

		<header>
	        <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-light bg-white border-bottom box-shadow mb-3">
	            <div class="container">
	                <a class="navbar-brand" href="<?php echo base_url() ?>index.php/Welcome/home">CRNI Enrollment System</a>
	                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbarSupportedContent"
	                        aria-expanded="false" aria-label="Toggle navigation">
	                    <span class="navbar-toggler-icon"></span>
	                </button>
	                <div class="navbar-collapse collapse d-sm-inline-flex flex-sm-row-reverse">
	                    <ul class="navbar-nav flex-grow-1">
	                        <li class="nav-item">
	                            <a class="nav-link text-dark" href="http://localhost/crnienrollment/pages/">Enrollment Reports</a>
	                        </li>
	                        <li class="nav-item">
	                            <a class="nav-link text-dark" href="<?php echo base_url() ?>index.php/Welcome/">Subjects</a>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	        </nav>
	    </header>

		<main role="main" class="pb-3">
		
		<div class="container">
			
			<div class="row">
    			<div class="col-md-4">

    				<h1>Add Subject</h1>

					<form action="<?php echo base_url() ?>index.php/Welcome/CreateStudent" method="post">
						<!--
						<div class="form-group">
			                <label class="control-label">Student ID</label>
							<input class="form-control" type="text" id="" name="Student_ID" />
							<span class="text-danger field-validation-valid" data-valmsg-for="Student_ID" data-valmsg-replace="true"></span>
			            </div>
			        	-->
						
			        	<div class="form-group">
			                <label class="control-label">Code</label>
			                <input class="form-control" type="text" id="" name="subject_code" />
			                <span class="text-danger field-validation-valid" data-valmsg-for="subject_code" data-valmsg-replace="true"></span>
			            </div>

			            <div class="form-group">
			                <label class="control-label">Description</label>
			                <input class="form-control" type="text" id="" name="subject_description" />
			                <span class="text-danger field-validation-valid" data-valmsg-for="subject_description" data-valmsg-replace="true"></span>
			            </div>

			            <div class="form-group">
			                <label class="control-label">Unit</label>
			                <input class="form-control" type="text" id="" name="subject_units" />
			                <span class="text-danger field-validation-valid" data-valmsg-for="subject_units" data-valmsg-replace="true"></span>
			            </div>

						<div class="form-group">
			                <input type="submit" value="Save" class="btn btn-primary" />
			            </div>
					</form>

				</div>
			</div>

			<div>
			    <a href="<?php echo base_url() ?>">Back to List</a>
			</div>

		</div>
		</main>
	</body>
</html>