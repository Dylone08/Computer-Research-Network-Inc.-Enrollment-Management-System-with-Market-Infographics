<html>
	<head>
		<title>CRNI Enrollment Management System</title>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
	</head>
	<body>
		
		<header>
	        <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-light bg-white border-bottom box-shadow mb-3">
	            <div class="container">
	                <a class="navbar-brand" href="<?php echo base_url() ?>index.php/Welcome/home">CRNI Enrollment System</a>
	                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbarSupportedContent"
	                        aria-expanded="false" aria-label="Toggle navigation">
	                    <span class="navbar-toggler-icon"></span>
	                </button>
	                <div class="navbar-collapse collapse d-sm-inline-flex flex-sm-row-reverse">
	                    <ul class="navbar-nav flex-grow-1">
	                        <li class="nav-item">
	                            <a class="nav-link text-dark" href="http://localhost/crnienrollment/pages/">Enrollment Reports</a>
	                        </li>
	                        <li class="nav-item">
	                            <a class="nav-link text-dark" href="<?php echo base_url() ?>index.php/Welcome/">Subjects</a>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	        </nav>
	    </header>



		<div class="container">
		<main role="main" class="pb-3">

		<h2>Tasks</h2>

		<ul class="navbar-nav flex-grow-1">
			<li><a href="<?php echo base_url() ?>index.php/Welcome/">View all Subjects</a></li>
			<li><a href="<?php echo base_url() ?>index.php/Welcome/Add">Add Subjects</a></li>
			<li><a href="<?php echo base_url() ?>index.php/Welcome/Specializations/">View Programs</a></li>
		</ul>

		</main>
		</div>

		<footer class="border-top footer text-muted">
	        <div class="container">
	            &copy; 2019 - CRNI Enrollment System - <a href="<?php echo base_url() ?>index.php/Privacy">Privacy</a>
	        </div>
	    </footer>


	</body>
</html>