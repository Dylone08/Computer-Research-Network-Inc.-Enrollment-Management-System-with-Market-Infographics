<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
		parent::__construct();
		$this->load->model('Example_model');
	}

	public function Specializations()
	{	
		$data['Specializations'] = $this->Example_model->getSpecializations();
		$this->load->view('Specializations_view',$data);
	}

	public function index()
	{	
		//$this->load->view('Example_view',$data);
		$data['Students'] = $this->Example_model->getStudentsList();
		$this->load->view('Example_view',$data);
	}

	public function home()
	{	
		//$this->load->view('Example_view',$data);
		$this->load->view('home');
	}

	public function EditSpecialization(){		
		$data['Specializations']=$this->Example_model->SearchSpecialization($this->uri->segment(3));
		$this->load->view('EditSpecialization_view',$data);
	}

	public function Edit(){		
		$data['Student']=$this->Example_model->SearchStudent1($this->uri->segment(3));
		$this->load->view('Example1_view',$data);
	}

	public function UpdateSpecialization(){
		$SID = $this->input->post('specialization_id');
		$data = array(
			'specialization_title'=>$this->input->post('specialization_title'),
			'strand_title'=>$this->input->post('strand_title'),
			'track_title'=>$this->input->post('track_title'));

		$this->Example_model->SaveSpecialization($SID,$data);

		$data['Specializations'] = $this->Example_model->getSpecializations();
		$this->load->view('Specializations_view',$data);
	}

	public function UpdateStudent(){
		$SID = $this->input->post('subject_code');
		$data = array(
			'subject_code'=>$this->input->post('new_subject_code'),
			'subject_description'=>$this->input->post('subject_description'),
			'subject_units'=>$this->input->post('subject_units'));

		$this->Example_model->SaveChanges($SID,$data);

		$data['Students'] = $this->Example_model->getStudentsList();
		$this->load->view('Example_view',$data);
	}

	public function DeleteSpecialization(){
		$SID=$this->uri->segment(3);

		$this->load->model('Example_model');
		$this->Example_model->DeleteSpecial($SID);

		$data['Specializations'] = $this->Example_model->getSpecializations();
		$this->load->view('Specializations_view',$data);
	}

	public function Delete(){
		$SID=$this->uri->segment(3);

		$this->load->model('Example_model');
		$this->Example_model->Delete($SID);

		$data['Students'] = $this->Example_model->getStudentsList();
		$this->load->view('Example_view',$data);
	}

	public function AddSpecialization(){		
		$this->load->view('CreateSpecialization');
	}

	public function Add(){		
		$this->load->view('CreateStudent');
	}

	public function SearchPrograms(){
		$SearchString = $this->input->post('SearchString');
		$category = $this->input->post('category');
		$data['Specializations'] = $this->Example_model->SearchProgram($category,$SearchString);		
		$this->load->view('SearchProgram',$data);
	}

	public function Search(){
		$SearchString = $this->input->post('SearchString');
		$category = $this->input->post('category');
		$data['Students'] = $this->Example_model->SearchStudent($category,$SearchString);		
		$this->load->view('Search',$data);
	}

	public function CreateSpecialization(){
		$specialization_title = $this->input->post('specialization_title');
		$strand_id = $this->input->post('strand_id');

		$this->Example_model->CreateSpecial($specialization_title,$strand_id);

		$data['Specializations'] = $this->Example_model->getSpecializations();
		$this->load->view('Specializations_view',$data);
	}

	public function CreateStudent(){
		$subject_code = $this->input->post('subject_code');
		$subject_description = $this->input->post('subject_description');
		$subject_units = $this->input->post('subject_units');

		$this->Example_model->Create($subject_code,$subject_description,$subject_units);

		$data['Students'] = $this->Example_model->getStudentsList();
		$this->load->view('Example_view',$data);
	}
}
