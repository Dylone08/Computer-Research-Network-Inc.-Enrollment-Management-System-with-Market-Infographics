<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Example extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Example_model');
	}

	public function index()
	{
		//$this->load->view('Example_view');
		$data['Students'] = $this->Example_model->getStudentsList();
		$this->load->view('Example_view',$data);
	}

	public function UpdateStudent(){
		$this->load->model('Example_model');
		
		$data['Student']=$this->Example_model->SearchStudent($this->uri->segment(3));
		$this->load->view('Example1_view',$data);
	}



}

?>