<?php

class Example_model extends CI_Model {

	function _construct(){
		parent::_construct();
	}

	public function getStudentsList(){

		$query = $this->db->query('SELECT * FROM subject_info');

		$arraydata = $query->result();

		return $arraydata;
	}

	public function SearchProgram($category,$SID){
		
		$StudentRecord = $this->db->query('SELECT * from specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id = track_info.track_id) ON specialization_info.strand_id = strand_info.strand_id WHERE ' . $category . ' LIKE "%' . $SID . '%"');

		$arraydata = $StudentRecord->result();

		return $arraydata;
	}

	public function SearchSpecialization($SID){
		
		$SpecializationRecord = $this->db->query('SELECT * from specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id = track_info.track_id) ON specialization_info.strand_id = strand_info.strand_id WHERE specialization_id = "' . $SID . '"');

		$arraydata = $SpecializationRecord->result();

		return $arraydata;
	}

	public function SearchStudent($category,$SID){
		
		$StudentRecord = $this->db->query('SELECT * FROM subject_info WHERE ' . $category . ' LIKE "%' . $SID . '%"');

		$arraydata = $StudentRecord->result();

		return $arraydata;
	}

	public function SearchStudent1($SID){
		
		$StudentRecord = $this->db->query('SELECT * FROM subject_info WHERE subject_code = "' . $SID . '"');

		$arraydata = $StudentRecord->result();

		return $arraydata;
	}

	public function SaveSpecialization($SID,$data){
		$this->db->set($data);
		$this->db->where("specialization_id",$SID);
		$this->db->update("specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id = track_info.track_id) ON specialization_info.strand_id",$data);
	}

	public function SaveChanges($SID,$data){
		$this->db->set($data);
		$this->db->where("subject_code",$SID);
		$this->db->update("subject_info",$data);
	}

	public function DeleteSpecial($SID){
		$this->db->query('DELETE from specialization_info where specialization_id = "' . $SID . '"');
	}

	public function Delete($SID){
		$this->db->query('DELETE from subject_info where subject_code = "' . $SID . '"');
	}

	public function CreateSpecial($title,$strand_id){
		$this->db->query("
			INSERT INTO specialization_info (specialization_title,strand_id)
			VALUES ('$title',$strand_id)");
	}

	public function Create($code,$description,$units){
		$this->db->query("
			INSERT INTO subject_info (subject_code,subject_description,subject_units)
			VALUES ('$code','$description','$units')");
	}

	public function getSpecializations(){

		$query = $this->db->query('SELECT * from specialization_info LEFT JOIN (strand_info LEFT JOIN track_info ON strand_info.track_id = track_info.track_id) ON specialization_info.strand_id = strand_info.strand_id');

		$arraydata = $query->result();

		return $arraydata;
	}

}

?>